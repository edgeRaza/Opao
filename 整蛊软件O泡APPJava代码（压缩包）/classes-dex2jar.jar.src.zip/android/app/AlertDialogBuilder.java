package android.app;

import android.content.Context;
import com.androlua.LuaDialog;

public class AlertDialogBuilder extends LuaDialog {
  public AlertDialogBuilder(Context paramContext) {
    super(paramContext);
  }
  
  public AlertDialogBuilder(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
}
