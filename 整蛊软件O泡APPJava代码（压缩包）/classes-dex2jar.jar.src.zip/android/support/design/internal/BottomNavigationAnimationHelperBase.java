package android.support.design.internal;

import android.view.ViewGroup;

class BottomNavigationAnimationHelperBase {
  void beginDelayedTransition(ViewGroup paramViewGroup) {}
}
