package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.VisibleForTesting;
import android.support.design.R;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

@DefaultBehavior(AppBarLayout.Behavior.class)
public class AppBarLayout extends LinearLayout {
  private static final int INVALID_SCROLL_RANGE = -1;
  
  static final int PENDING_ACTION_ANIMATE_ENABLED = 4;
  
  static final int PENDING_ACTION_COLLAPSED = 2;
  
  static final int PENDING_ACTION_EXPANDED = 1;
  
  static final int PENDING_ACTION_FORCE = 8;
  
  static final int PENDING_ACTION_NONE = 0;
  
  private boolean mCollapsed;
  
  private boolean mCollapsible;
  
  private int mDownPreScrollRange = -1;
  
  private int mDownScrollRange = -1;
  
  private boolean mHaveChildWithInterpolator;
  
  private WindowInsetsCompat mLastInsets;
  
  private List<OnOffsetChangedListener> mListeners;
  
  private int mPendingAction = 0;
  
  private final int[] mTmpStatesArray = new int[2];
  
  private int mTotalScrollRange = -1;
  
  public AppBarLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public AppBarLayout(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setOrientation(1);
    ThemeUtils.checkAppCompatTheme(paramContext);
    if (Build.VERSION.SDK_INT >= 21) {
      ViewUtilsLollipop.setBoundsViewOutlineProvider((View)this);
      ViewUtilsLollipop.setStateListAnimatorFromAttrs((View)this, paramAttributeSet, 0, R.style.Widget_Design_AppBarLayout);
    } 
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.AppBarLayout, 0, R.style.Widget_Design_AppBarLayout);
    ViewCompat.setBackground((View)this, typedArray.getDrawable(R.styleable.AppBarLayout_android_background));
    if (typedArray.hasValue(R.styleable.AppBarLayout_expanded))
      setExpanded(typedArray.getBoolean(R.styleable.AppBarLayout_expanded, false), false, false); 
    if (Build.VERSION.SDK_INT >= 21 && typedArray.hasValue(R.styleable.AppBarLayout_elevation))
      ViewUtilsLollipop.setDefaultAppBarLayoutStateListAnimator((View)this, typedArray.getDimensionPixelSize(R.styleable.AppBarLayout_elevation, 0)); 
    typedArray.recycle();
    ViewCompat.setOnApplyWindowInsetsListener((View)this, new OnApplyWindowInsetsListener() {
          public WindowInsetsCompat onApplyWindowInsets(View param1View, WindowInsetsCompat param1WindowInsetsCompat) {
            return AppBarLayout.this.onWindowInsetChanged(param1WindowInsetsCompat);
          }
        });
  }
  
  private void invalidateScrollRanges() {
    this.mTotalScrollRange = -1;
    this.mDownPreScrollRange = -1;
    this.mDownScrollRange = -1;
  }
  
  private boolean setCollapsibleState(boolean paramBoolean) {
    if (this.mCollapsible != paramBoolean) {
      this.mCollapsible = paramBoolean;
      refreshDrawableState();
      return true;
    } 
    return false;
  }
  
  private void setExpanded(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    byte b1;
    byte b2;
    byte b3 = 0;
    if (paramBoolean1) {
      b1 = 1;
    } else {
      b1 = 2;
    } 
    if (paramBoolean2) {
      b2 = 4;
    } else {
      b2 = 0;
    } 
    if (paramBoolean3)
      b3 = 8; 
    this.mPendingAction = b3 | b2 | b1;
    requestLayout();
  }
  
  private void updateCollapsible() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getChildCount : ()I
    //   4: istore_2
    //   5: iconst_0
    //   6: istore_1
    //   7: iload_1
    //   8: iload_2
    //   9: if_icmpge -> 45
    //   12: aload_0
    //   13: iload_1
    //   14: invokevirtual getChildAt : (I)Landroid/view/View;
    //   17: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   20: checkcast android/support/design/widget/AppBarLayout$LayoutParams
    //   23: invokevirtual isCollapsible : ()Z
    //   26: ifeq -> 38
    //   29: iconst_1
    //   30: istore_3
    //   31: aload_0
    //   32: iload_3
    //   33: invokespecial setCollapsibleState : (Z)Z
    //   36: pop
    //   37: return
    //   38: iload_1
    //   39: iconst_1
    //   40: iadd
    //   41: istore_1
    //   42: goto -> 7
    //   45: iconst_0
    //   46: istore_3
    //   47: goto -> 31
  }
  
  public void addOnOffsetChangedListener(OnOffsetChangedListener paramOnOffsetChangedListener) {
    if (this.mListeners == null)
      this.mListeners = new ArrayList<OnOffsetChangedListener>(); 
    if (paramOnOffsetChangedListener != null && !this.mListeners.contains(paramOnOffsetChangedListener))
      this.mListeners.add(paramOnOffsetChangedListener); 
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return paramLayoutParams instanceof LayoutParams;
  }
  
  void dispatchOffsetUpdates(int paramInt) {
    if (this.mListeners != null) {
      int j = this.mListeners.size();
      for (int i = 0; i < j; i++) {
        OnOffsetChangedListener onOffsetChangedListener = this.mListeners.get(i);
        if (onOffsetChangedListener != null)
          onOffsetChangedListener.onOffsetChanged(this, paramInt); 
      } 
    } 
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-1, -2);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (Build.VERSION.SDK_INT >= 19 && paramLayoutParams instanceof LinearLayout.LayoutParams) ? new LayoutParams((LinearLayout.LayoutParams)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams));
  }
  
  int getDownNestedPreScrollRange() {
    if (this.mDownPreScrollRange != -1)
      return this.mDownPreScrollRange; 
    int j = getChildCount() - 1;
    int i = 0;
    while (j >= 0) {
      View view = getChildAt(j);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      int k = view.getMeasuredHeight();
      int m = layoutParams.mScrollFlags;
      if ((m & 0x5) == 5) {
        int n = layoutParams.topMargin;
        i = layoutParams.bottomMargin + n + i;
        if ((m & 0x8) != 0) {
          i += ViewCompat.getMinimumHeight(view);
        } else if ((m & 0x2) != 0) {
          i += k - ViewCompat.getMinimumHeight(view);
        } else {
          i += k - getTopInset();
        } 
      } else if (i > 0) {
        break;
      } 
      j--;
    } 
    i = Math.max(0, i);
    this.mDownPreScrollRange = i;
    return i;
  }
  
  int getDownNestedScrollRange() {
    if (this.mDownScrollRange != -1)
      return this.mDownScrollRange; 
    int k = getChildCount();
    int j = 0;
    int i = 0;
    while (true) {
      if (j < k) {
        View view = getChildAt(j);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        int n = view.getMeasuredHeight();
        int i1 = layoutParams.topMargin;
        int i2 = layoutParams.bottomMargin;
        int m = layoutParams.mScrollFlags;
        if ((m & 0x1) != 0) {
          i += n + i1 + i2;
          if ((m & 0x2) != 0) {
            i -= ViewCompat.getMinimumHeight(view) + getTopInset();
            i = Math.max(0, i);
            this.mDownScrollRange = i;
            return i;
          } 
        } else {
          i = Math.max(0, i);
          this.mDownScrollRange = i;
          return i;
        } 
      } else {
        i = Math.max(0, i);
        this.mDownScrollRange = i;
        return i;
      } 
      j++;
    } 
  }
  
  final int getMinimumHeightForVisibleOverlappingContent() {
    int j = getTopInset();
    int i = ViewCompat.getMinimumHeight((View)this);
    if (i != 0)
      return i * 2 + j; 
    i = getChildCount();
    if (i >= 1) {
      i = ViewCompat.getMinimumHeight(getChildAt(i - 1));
    } else {
      i = 0;
    } 
    return (i != 0) ? (i * 2 + j) : (getHeight() / 3);
  }
  
  int getPendingAction() {
    return this.mPendingAction;
  }
  
  @Deprecated
  public float getTargetElevation() {
    return 0.0F;
  }
  
  @VisibleForTesting
  final int getTopInset() {
    return (this.mLastInsets != null) ? this.mLastInsets.getSystemWindowInsetTop() : 0;
  }
  
  public final int getTotalScrollRange() {
    if (this.mTotalScrollRange != -1)
      return this.mTotalScrollRange; 
    int k = getChildCount();
    int j = 0;
    int i = 0;
    while (true) {
      if (j < k) {
        View view = getChildAt(j);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        int n = view.getMeasuredHeight();
        int m = layoutParams.mScrollFlags;
        if ((m & 0x1) != 0) {
          int i1 = layoutParams.topMargin;
          i += layoutParams.bottomMargin + n + i1;
          if ((m & 0x2) != 0) {
            i -= ViewCompat.getMinimumHeight(view);
            i = Math.max(0, i - getTopInset());
            this.mTotalScrollRange = i;
            return i;
          } 
        } else {
          i = Math.max(0, i - getTopInset());
          this.mTotalScrollRange = i;
          return i;
        } 
      } else {
        i = Math.max(0, i - getTopInset());
        this.mTotalScrollRange = i;
        return i;
      } 
      j++;
    } 
  }
  
  int getUpNestedPreScrollRange() {
    return getTotalScrollRange();
  }
  
  boolean hasChildWithInterpolator() {
    return this.mHaveChildWithInterpolator;
  }
  
  boolean hasScrollableChildren() {
    return (getTotalScrollRange() != 0);
  }
  
  protected int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt1 = this.mTmpStatesArray;
    int[] arrayOfInt2 = super.onCreateDrawableState(arrayOfInt1.length + paramInt);
    if (this.mCollapsible) {
      paramInt = R.attr.state_collapsible;
    } else {
      paramInt = -R.attr.state_collapsible;
    } 
    arrayOfInt1[0] = paramInt;
    if (this.mCollapsible && this.mCollapsed) {
      paramInt = R.attr.state_collapsed;
      arrayOfInt1[1] = paramInt;
      return mergeDrawableStates(arrayOfInt2, arrayOfInt1);
    } 
    paramInt = -R.attr.state_collapsed;
    arrayOfInt1[1] = paramInt;
    return mergeDrawableStates(arrayOfInt2, arrayOfInt1);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    invalidateScrollRanges();
    this.mHaveChildWithInterpolator = false;
    paramInt2 = getChildCount();
    paramInt1 = 0;
    while (true) {
      if (paramInt1 < paramInt2)
        if (((LayoutParams)getChildAt(paramInt1).getLayoutParams()).getScrollInterpolator() != null) {
          this.mHaveChildWithInterpolator = true;
        } else {
          paramInt1++;
          continue;
        }  
      updateCollapsible();
      return;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    invalidateScrollRanges();
  }
  
  WindowInsetsCompat onWindowInsetChanged(WindowInsetsCompat paramWindowInsetsCompat) {
    WindowInsetsCompat windowInsetsCompat = null;
    if (ViewCompat.getFitsSystemWindows((View)this))
      windowInsetsCompat = paramWindowInsetsCompat; 
    if (!ViewUtils.objectEquals(this.mLastInsets, windowInsetsCompat)) {
      this.mLastInsets = windowInsetsCompat;
      invalidateScrollRanges();
    } 
    return paramWindowInsetsCompat;
  }
  
  public void removeOnOffsetChangedListener(OnOffsetChangedListener paramOnOffsetChangedListener) {
    if (this.mListeners != null && paramOnOffsetChangedListener != null)
      this.mListeners.remove(paramOnOffsetChangedListener); 
  }
  
  void resetPendingAction() {
    this.mPendingAction = 0;
  }
  
  boolean setCollapsedState(boolean paramBoolean) {
    if (this.mCollapsed != paramBoolean) {
      this.mCollapsed = paramBoolean;
      refreshDrawableState();
      return true;
    } 
    return false;
  }
  
  public void setExpanded(boolean paramBoolean) {
    setExpanded(paramBoolean, ViewCompat.isLaidOut((View)this));
  }
  
  public void setExpanded(boolean paramBoolean1, boolean paramBoolean2) {
    setExpanded(paramBoolean1, paramBoolean2, true);
  }
  
  public void setOrientation(int paramInt) {
    if (paramInt != 1)
      throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation"); 
    super.setOrientation(paramInt);
  }
  
  @Deprecated
  public void setTargetElevation(float paramFloat) {
    if (Build.VERSION.SDK_INT >= 21)
      ViewUtilsLollipop.setDefaultAppBarLayoutStateListAnimator((View)this, paramFloat); 
  }
  
  public static class Behavior extends HeaderBehavior<AppBarLayout> {
    private static final int INVALID_POSITION = -1;
    
    private static final int MAX_OFFSET_ANIMATION_DURATION = 600;
    
    private WeakReference<View> mLastNestedScrollingChildRef;
    
    private ValueAnimatorCompat mOffsetAnimator;
    
    private int mOffsetDelta;
    
    private int mOffsetToChildIndexOnLayout = -1;
    
    private boolean mOffsetToChildIndexOnLayoutIsMinHeight;
    
    private float mOffsetToChildIndexOnLayoutPerc;
    
    private DragCallback mOnDragCallback;
    
    private boolean mSkipNestedPreScroll;
    
    private boolean mWasNestedFlung;
    
    public Behavior() {}
    
    public Behavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    private void animateOffsetTo(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, int param1Int, float param1Float) {
      int i = Math.abs(getTopBottomOffsetForScrollingSibling() - param1Int);
      param1Float = Math.abs(param1Float);
      if (param1Float > 0.0F) {
        i = Math.round(i / param1Float * 1000.0F) * 3;
      } else {
        i = (int)((i / param1AppBarLayout.getHeight() + 1.0F) * 150.0F);
      } 
      animateOffsetWithDuration(param1CoordinatorLayout, param1AppBarLayout, param1Int, i);
    }
    
    private void animateOffsetWithDuration(final CoordinatorLayout coordinatorLayout, final AppBarLayout child, int param1Int1, int param1Int2) {
      int i = getTopBottomOffsetForScrollingSibling();
      if (i == param1Int1) {
        if (this.mOffsetAnimator != null && this.mOffsetAnimator.isRunning())
          this.mOffsetAnimator.cancel(); 
        return;
      } 
      if (this.mOffsetAnimator == null) {
        this.mOffsetAnimator = ViewUtils.createAnimator();
        this.mOffsetAnimator.setInterpolator(AnimationUtils.DECELERATE_INTERPOLATOR);
        this.mOffsetAnimator.addUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener() {
              public void onAnimationUpdate(ValueAnimatorCompat param2ValueAnimatorCompat) {
                AppBarLayout.Behavior.this.setHeaderTopBottomOffset(coordinatorLayout, child, param2ValueAnimatorCompat.getAnimatedIntValue());
              }
            });
      } else {
        this.mOffsetAnimator.cancel();
      } 
      this.mOffsetAnimator.setDuration(Math.min(param1Int2, 600));
      this.mOffsetAnimator.setIntValues(i, param1Int1);
      this.mOffsetAnimator.start();
    }
    
    private static boolean checkFlag(int param1Int1, int param1Int2) {
      return ((param1Int1 & param1Int2) == param1Int2);
    }
    
    private static View getAppBarChildOnOffset(AppBarLayout param1AppBarLayout, int param1Int) {
      int i = Math.abs(param1Int);
      int j = param1AppBarLayout.getChildCount();
      for (param1Int = 0; param1Int < j; param1Int++) {
        View view = param1AppBarLayout.getChildAt(param1Int);
        if (i >= view.getTop() && i <= view.getBottom())
          return view; 
      } 
      return null;
    }
    
    private int getChildIndexOnOffset(AppBarLayout param1AppBarLayout, int param1Int) {
      int i = 0;
      int j = param1AppBarLayout.getChildCount();
      while (i < j) {
        View view = param1AppBarLayout.getChildAt(i);
        if (view.getTop() <= -param1Int && view.getBottom() >= -param1Int)
          return i; 
        i++;
      } 
      return -1;
    }
    
    private int interpolateOffset(AppBarLayout param1AppBarLayout, int param1Int) {
      int j = Math.abs(param1Int);
      int k = param1AppBarLayout.getChildCount();
      for (int i = 0;; i++) {
        int m = param1Int;
        if (i < k) {
          View view = param1AppBarLayout.getChildAt(i);
          AppBarLayout.LayoutParams layoutParams = (AppBarLayout.LayoutParams)view.getLayoutParams();
          Interpolator interpolator = layoutParams.getScrollInterpolator();
          if (j >= view.getTop() && j <= view.getBottom()) {
            m = param1Int;
            if (interpolator != null) {
              k = layoutParams.getScrollFlags();
              if ((k & 0x1) != 0) {
                m = view.getHeight();
                i = layoutParams.topMargin;
                i = layoutParams.bottomMargin + m + i + 0;
                m = i;
                if ((k & 0x2) != 0)
                  m = i - ViewCompat.getMinimumHeight(view); 
              } else {
                m = 0;
              } 
              i = m;
              if (ViewCompat.getFitsSystemWindows(view))
                i = m - param1AppBarLayout.getTopInset(); 
              m = param1Int;
              if (i > 0) {
                m = view.getTop();
                float f = i;
                m = Math.round(interpolator.getInterpolation((j - m) / i) * f);
                m = Integer.signum(param1Int) * (m + view.getTop());
              } 
            } 
            return m;
          } 
        } else {
          return m;
        } 
      } 
    }
    
    private boolean shouldJumpElevationState(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout) {
      List<View> list = param1CoordinatorLayout.getDependents((View)param1AppBarLayout);
      int j = list.size();
      for (int i = 0; i < j; i++) {
        CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams)((View)list.get(i)).getLayoutParams()).getBehavior();
        if (behavior instanceof AppBarLayout.ScrollingViewBehavior)
          return (((AppBarLayout.ScrollingViewBehavior)behavior).getOverlayTop() != 0); 
      } 
      return false;
    }
    
    private void snapToChildIfNeeded(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout) {
      int i = getTopBottomOffsetForScrollingSibling();
      int j = getChildIndexOnOffset(param1AppBarLayout, i);
      if (j >= 0) {
        View view = param1AppBarLayout.getChildAt(j);
        int k = ((AppBarLayout.LayoutParams)view.getLayoutParams()).getScrollFlags();
        if ((k & 0x11) == 17) {
          int i1 = -view.getTop();
          int m = -view.getBottom();
          int n = m;
          if (j == param1AppBarLayout.getChildCount() - 1)
            n = m + param1AppBarLayout.getTopInset(); 
          if (checkFlag(k, 2)) {
            n += ViewCompat.getMinimumHeight(view);
            m = i1;
          } else if (checkFlag(k, 5)) {
            k = ViewCompat.getMinimumHeight(view) + n;
            m = k;
            if (i >= k) {
              n = k;
              m = i1;
            } 
          } else {
            m = i1;
          } 
          if (i >= (n + m) / 2)
            n = m; 
          animateOffsetTo(param1CoordinatorLayout, param1AppBarLayout, MathUtils.constrain(n, -param1AppBarLayout.getTotalScrollRange(), 0), 0.0F);
        } 
      } 
    }
    
    private void updateAppBarLayoutDrawableState(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, int param1Int1, int param1Int2, boolean param1Boolean) {
      boolean bool1 = true;
      boolean bool2 = false;
      View view = getAppBarChildOnOffset(param1AppBarLayout, param1Int1);
      if (view != null) {
        int i = ((AppBarLayout.LayoutParams)view.getLayoutParams()).getScrollFlags();
        boolean bool = bool2;
        if ((i & 0x1) != 0) {
          int j = ViewCompat.getMinimumHeight(view);
          if (param1Int2 > 0 && (i & 0xC) != 0) {
            if (-param1Int1 >= view.getBottom() - j - param1AppBarLayout.getTopInset()) {
              bool = true;
            } else {
              bool = false;
            } 
          } else {
            bool = bool2;
            if ((i & 0x2) != 0)
              if (-param1Int1 >= view.getBottom() - j - param1AppBarLayout.getTopInset()) {
                bool = bool1;
              } else {
                bool = false;
              }  
          } 
        } 
        bool = param1AppBarLayout.setCollapsedState(bool);
        if (Build.VERSION.SDK_INT >= 11 && (param1Boolean || (bool && shouldJumpElevationState(param1CoordinatorLayout, param1AppBarLayout))))
          param1AppBarLayout.jumpDrawablesToCurrentState(); 
      } 
    }
    
    boolean canDragView(AppBarLayout param1AppBarLayout) {
      if (this.mOnDragCallback != null)
        return this.mOnDragCallback.canDrag(param1AppBarLayout); 
      if (this.mLastNestedScrollingChildRef != null) {
        View view = this.mLastNestedScrollingChildRef.get();
        return (view != null && view.isShown() && !ViewCompat.canScrollVertically(view, -1));
      } 
      return true;
    }
    
    int getMaxDragOffset(AppBarLayout param1AppBarLayout) {
      return -param1AppBarLayout.getDownNestedScrollRange();
    }
    
    int getScrollRangeForDragFling(AppBarLayout param1AppBarLayout) {
      return param1AppBarLayout.getTotalScrollRange();
    }
    
    int getTopBottomOffsetForScrollingSibling() {
      return getTopAndBottomOffset() + this.mOffsetDelta;
    }
    
    @VisibleForTesting
    boolean isOffsetAnimatorRunning() {
      return (this.mOffsetAnimator != null && this.mOffsetAnimator.isRunning());
    }
    
    void onFlingFinished(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout) {
      snapToChildIfNeeded(param1CoordinatorLayout, param1AppBarLayout);
    }
    
    public boolean onLayoutChild(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, int param1Int) {
      boolean bool = super.onLayoutChild(param1CoordinatorLayout, param1AppBarLayout, param1Int);
      int i = param1AppBarLayout.getPendingAction();
      if (this.mOffsetToChildIndexOnLayout >= 0 && (i & 0x8) == 0) {
        View view = param1AppBarLayout.getChildAt(this.mOffsetToChildIndexOnLayout);
        param1Int = -view.getBottom();
        if (this.mOffsetToChildIndexOnLayoutIsMinHeight) {
          param1Int = ViewCompat.getMinimumHeight(view) + param1AppBarLayout.getTopInset() + param1Int;
        } else {
          param1Int = Math.round(view.getHeight() * this.mOffsetToChildIndexOnLayoutPerc) + param1Int;
        } 
        setHeaderTopBottomOffset(param1CoordinatorLayout, param1AppBarLayout, param1Int);
        param1AppBarLayout.resetPendingAction();
        this.mOffsetToChildIndexOnLayout = -1;
        setTopAndBottomOffset(MathUtils.constrain(getTopAndBottomOffset(), -param1AppBarLayout.getTotalScrollRange(), 0));
        updateAppBarLayoutDrawableState(param1CoordinatorLayout, param1AppBarLayout, getTopAndBottomOffset(), 0, true);
        param1AppBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
        return bool;
      } 
      if (i != 0) {
        if ((i & 0x4) != 0) {
          param1Int = 1;
        } else {
          param1Int = 0;
        } 
        if ((i & 0x2) != 0) {
          i = -param1AppBarLayout.getUpNestedPreScrollRange();
          if (param1Int != 0) {
            animateOffsetTo(param1CoordinatorLayout, param1AppBarLayout, i, 0.0F);
            param1AppBarLayout.resetPendingAction();
            this.mOffsetToChildIndexOnLayout = -1;
            setTopAndBottomOffset(MathUtils.constrain(getTopAndBottomOffset(), -param1AppBarLayout.getTotalScrollRange(), 0));
            updateAppBarLayoutDrawableState(param1CoordinatorLayout, param1AppBarLayout, getTopAndBottomOffset(), 0, true);
            param1AppBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
            return bool;
          } 
          setHeaderTopBottomOffset(param1CoordinatorLayout, param1AppBarLayout, i);
          param1AppBarLayout.resetPendingAction();
          this.mOffsetToChildIndexOnLayout = -1;
          setTopAndBottomOffset(MathUtils.constrain(getTopAndBottomOffset(), -param1AppBarLayout.getTotalScrollRange(), 0));
          updateAppBarLayoutDrawableState(param1CoordinatorLayout, param1AppBarLayout, getTopAndBottomOffset(), 0, true);
          param1AppBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
          return bool;
        } 
        if ((i & 0x1) != 0) {
          if (param1Int != 0) {
            animateOffsetTo(param1CoordinatorLayout, param1AppBarLayout, 0, 0.0F);
            param1AppBarLayout.resetPendingAction();
            this.mOffsetToChildIndexOnLayout = -1;
            setTopAndBottomOffset(MathUtils.constrain(getTopAndBottomOffset(), -param1AppBarLayout.getTotalScrollRange(), 0));
            updateAppBarLayoutDrawableState(param1CoordinatorLayout, param1AppBarLayout, getTopAndBottomOffset(), 0, true);
            param1AppBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
            return bool;
          } 
          setHeaderTopBottomOffset(param1CoordinatorLayout, param1AppBarLayout, 0);
        } 
      } 
      param1AppBarLayout.resetPendingAction();
      this.mOffsetToChildIndexOnLayout = -1;
      setTopAndBottomOffset(MathUtils.constrain(getTopAndBottomOffset(), -param1AppBarLayout.getTotalScrollRange(), 0));
      updateAppBarLayoutDrawableState(param1CoordinatorLayout, param1AppBarLayout, getTopAndBottomOffset(), 0, true);
      param1AppBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
      return bool;
    }
    
    public boolean onMeasureChild(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (((CoordinatorLayout.LayoutParams)param1AppBarLayout.getLayoutParams()).height == -2) {
        param1CoordinatorLayout.onMeasureChild((View)param1AppBarLayout, param1Int1, param1Int2, View.MeasureSpec.makeMeasureSpec(0, 0), param1Int4);
        return true;
      } 
      return super.onMeasureChild(param1CoordinatorLayout, param1AppBarLayout, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public boolean onNestedFling(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      boolean bool = false;
      if (!param1Boolean) {
        param1Boolean = fling(param1CoordinatorLayout, param1AppBarLayout, -param1AppBarLayout.getTotalScrollRange(), 0, -param1Float2);
        this.mWasNestedFlung = param1Boolean;
        return param1Boolean;
      } 
      if (param1Float2 < 0.0F) {
        int j = -param1AppBarLayout.getTotalScrollRange() + param1AppBarLayout.getDownNestedPreScrollRange();
        param1Boolean = bool;
        if (getTopBottomOffsetForScrollingSibling() < j) {
          animateOffsetTo(param1CoordinatorLayout, param1AppBarLayout, j, param1Float2);
          param1Boolean = true;
        } 
        this.mWasNestedFlung = param1Boolean;
        return param1Boolean;
      } 
      int i = -param1AppBarLayout.getUpNestedPreScrollRange();
      param1Boolean = bool;
      if (getTopBottomOffsetForScrollingSibling() > i) {
        animateOffsetTo(param1CoordinatorLayout, param1AppBarLayout, i, param1Float2);
        param1Boolean = true;
      } 
      this.mWasNestedFlung = param1Boolean;
      return param1Boolean;
    }
    
    public void onNestedPreScroll(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, View param1View, int param1Int1, int param1Int2, int[] param1ArrayOfint) {
      if (param1Int2 != 0 && !this.mSkipNestedPreScroll) {
        boolean bool;
        if (param1Int2 < 0) {
          param1Int1 = -param1AppBarLayout.getTotalScrollRange();
          bool = param1Int1 + param1AppBarLayout.getDownNestedPreScrollRange();
        } else {
          param1Int1 = -param1AppBarLayout.getUpNestedPreScrollRange();
          bool = false;
        } 
        param1ArrayOfint[1] = scroll(param1CoordinatorLayout, param1AppBarLayout, param1Int2, param1Int1, bool);
      } 
    }
    
    public void onNestedScroll(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (param1Int4 < 0) {
        scroll(param1CoordinatorLayout, param1AppBarLayout, param1Int4, -param1AppBarLayout.getDownNestedScrollRange(), 0);
        this.mSkipNestedPreScroll = true;
        return;
      } 
      this.mSkipNestedPreScroll = false;
    }
    
    public void onRestoreInstanceState(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, Parcelable param1Parcelable) {
      SavedState savedState;
      if (param1Parcelable instanceof SavedState) {
        savedState = (SavedState)param1Parcelable;
        super.onRestoreInstanceState(param1CoordinatorLayout, param1AppBarLayout, savedState.getSuperState());
        this.mOffsetToChildIndexOnLayout = savedState.firstVisibleChildIndex;
        this.mOffsetToChildIndexOnLayoutPerc = savedState.firstVisibleChildPercentageShown;
        this.mOffsetToChildIndexOnLayoutIsMinHeight = savedState.firstVisibleChildAtMinimumHeight;
        return;
      } 
      super.onRestoreInstanceState(param1CoordinatorLayout, param1AppBarLayout, (Parcelable)savedState);
      this.mOffsetToChildIndexOnLayout = -1;
    }
    
    public Parcelable onSaveInstanceState(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout) {
      SavedState savedState;
      boolean bool = false;
      Parcelable parcelable = super.onSaveInstanceState(param1CoordinatorLayout, param1AppBarLayout);
      int j = getTopAndBottomOffset();
      int k = param1AppBarLayout.getChildCount();
      for (int i = 0; i < k; i++) {
        View view = param1AppBarLayout.getChildAt(i);
        int m = view.getBottom() + j;
        if (view.getTop() + j <= 0 && m >= 0) {
          savedState = new SavedState(parcelable);
          savedState.firstVisibleChildIndex = i;
          if (m == ViewCompat.getMinimumHeight(view) + param1AppBarLayout.getTopInset())
            bool = true; 
          savedState.firstVisibleChildAtMinimumHeight = bool;
          savedState.firstVisibleChildPercentageShown = m / view.getHeight();
          return (Parcelable)savedState;
        } 
      } 
      return (Parcelable)savedState;
    }
    
    public boolean onStartNestedScroll(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, View param1View1, View param1View2, int param1Int) {
      boolean bool;
      if ((param1Int & 0x2) != 0 && param1AppBarLayout.hasScrollableChildren() && param1CoordinatorLayout.getHeight() - param1View1.getHeight() <= param1AppBarLayout.getHeight()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.mOffsetAnimator != null)
        this.mOffsetAnimator.cancel(); 
      this.mLastNestedScrollingChildRef = null;
      return bool;
    }
    
    public void onStopNestedScroll(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, View param1View) {
      if (!this.mWasNestedFlung)
        snapToChildIfNeeded(param1CoordinatorLayout, param1AppBarLayout); 
      this.mSkipNestedPreScroll = false;
      this.mWasNestedFlung = false;
      this.mLastNestedScrollingChildRef = new WeakReference<View>(param1View);
    }
    
    public void setDragCallback(@Nullable DragCallback param1DragCallback) {
      this.mOnDragCallback = param1DragCallback;
    }
    
    int setHeaderTopBottomOffset(CoordinatorLayout param1CoordinatorLayout, AppBarLayout param1AppBarLayout, int param1Int1, int param1Int2, int param1Int3) {
      boolean bool = false;
      int i = getTopBottomOffsetForScrollingSibling();
      if (param1Int2 != 0 && i >= param1Int2 && i <= param1Int3) {
        param1Int2 = MathUtils.constrain(param1Int1, param1Int2, param1Int3);
        param1Int1 = bool;
        if (i != param1Int2) {
          if (param1AppBarLayout.hasChildWithInterpolator()) {
            param1Int1 = interpolateOffset(param1AppBarLayout, param1Int2);
          } else {
            param1Int1 = param1Int2;
          } 
          boolean bool1 = setTopAndBottomOffset(param1Int1);
          this.mOffsetDelta = param1Int2 - param1Int1;
          if (!bool1 && param1AppBarLayout.hasChildWithInterpolator())
            param1CoordinatorLayout.dispatchDependentViewsChanged((View)param1AppBarLayout); 
          param1AppBarLayout.dispatchOffsetUpdates(getTopAndBottomOffset());
          if (param1Int2 < i) {
            param1Int1 = -1;
          } else {
            param1Int1 = 1;
          } 
          updateAppBarLayoutDrawableState(param1CoordinatorLayout, param1AppBarLayout, param1Int2, param1Int1, false);
          param1Int1 = i - param1Int2;
        } 
        return param1Int1;
      } 
      this.mOffsetDelta = 0;
      return 0;
    }
    
    public static abstract class DragCallback {
      public abstract boolean canDrag(@NonNull AppBarLayout param2AppBarLayout);
    }
    
    protected static class SavedState extends AbsSavedState {
      public static final Parcelable.Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new ParcelableCompatCreatorCallbacks<SavedState>() {
            public AppBarLayout.Behavior.SavedState createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
              return new AppBarLayout.Behavior.SavedState(param3Parcel, param3ClassLoader);
            }
            
            public AppBarLayout.Behavior.SavedState[] newArray(int param3Int) {
              return new AppBarLayout.Behavior.SavedState[param3Int];
            }
          });
      
      boolean firstVisibleChildAtMinimumHeight;
      
      int firstVisibleChildIndex;
      
      float firstVisibleChildPercentageShown;
      
      public SavedState(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        super(param2Parcel, param2ClassLoader);
        boolean bool;
        this.firstVisibleChildIndex = param2Parcel.readInt();
        this.firstVisibleChildPercentageShown = param2Parcel.readFloat();
        if (param2Parcel.readByte() != 0) {
          bool = true;
        } else {
          bool = false;
        } 
        this.firstVisibleChildAtMinimumHeight = bool;
      }
      
      public SavedState(Parcelable param2Parcelable) {
        super(param2Parcelable);
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        super.writeToParcel(param2Parcel, param2Int);
        param2Parcel.writeInt(this.firstVisibleChildIndex);
        param2Parcel.writeFloat(this.firstVisibleChildPercentageShown);
        if (this.firstVisibleChildAtMinimumHeight) {
          param2Int = 1;
        } else {
          param2Int = 0;
        } 
        param2Parcel.writeByte((byte)param2Int);
      }
    }
    
    static final class null implements ParcelableCompatCreatorCallbacks<SavedState> {
      public AppBarLayout.Behavior.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new AppBarLayout.Behavior.SavedState(param2Parcel, param2ClassLoader);
      }
      
      public AppBarLayout.Behavior.SavedState[] newArray(int param2Int) {
        return new AppBarLayout.Behavior.SavedState[param2Int];
      }
    }
  }
  
  class null implements ValueAnimatorCompat.AnimatorUpdateListener {
    public void onAnimationUpdate(ValueAnimatorCompat param1ValueAnimatorCompat) {
      this.this$0.setHeaderTopBottomOffset(coordinatorLayout, child, param1ValueAnimatorCompat.getAnimatedIntValue());
    }
  }
  
  public static abstract class DragCallback {
    public abstract boolean canDrag(@NonNull AppBarLayout param1AppBarLayout);
  }
  
  protected static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new ParcelableCompatCreatorCallbacks<SavedState>() {
          public AppBarLayout.Behavior.SavedState createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
            return new AppBarLayout.Behavior.SavedState(param3Parcel, param3ClassLoader);
          }
          
          public AppBarLayout.Behavior.SavedState[] newArray(int param3Int) {
            return new AppBarLayout.Behavior.SavedState[param3Int];
          }
        });
    
    boolean firstVisibleChildAtMinimumHeight;
    
    int firstVisibleChildIndex;
    
    float firstVisibleChildPercentageShown;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.firstVisibleChildIndex = param1Parcel.readInt();
      this.firstVisibleChildPercentageShown = param1Parcel.readFloat();
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.firstVisibleChildAtMinimumHeight = bool;
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.firstVisibleChildIndex);
      param1Parcel.writeFloat(this.firstVisibleChildPercentageShown);
      if (this.firstVisibleChildAtMinimumHeight) {
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      param1Parcel.writeByte((byte)param1Int);
    }
  }
  
  static final class null implements ParcelableCompatCreatorCallbacks<Behavior.SavedState> {
    public AppBarLayout.Behavior.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new AppBarLayout.Behavior.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public AppBarLayout.Behavior.SavedState[] newArray(int param1Int) {
      return new AppBarLayout.Behavior.SavedState[param1Int];
    }
  }
  
  public static class LayoutParams extends LinearLayout.LayoutParams {
    static final int COLLAPSIBLE_FLAGS = 10;
    
    static final int FLAG_QUICK_RETURN = 5;
    
    static final int FLAG_SNAP = 17;
    
    public static final int SCROLL_FLAG_ENTER_ALWAYS = 4;
    
    public static final int SCROLL_FLAG_ENTER_ALWAYS_COLLAPSED = 8;
    
    public static final int SCROLL_FLAG_EXIT_UNTIL_COLLAPSED = 2;
    
    public static final int SCROLL_FLAG_SCROLL = 1;
    
    public static final int SCROLL_FLAG_SNAP = 16;
    
    int mScrollFlags = 1;
    
    Interpolator mScrollInterpolator;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(int param1Int1, int param1Int2, float param1Float) {
      super(param1Int1, param1Int2, param1Float);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.AppBarLayout_Layout);
      this.mScrollFlags = typedArray.getInt(R.styleable.AppBarLayout_Layout_layout_scrollFlags, 0);
      if (typedArray.hasValue(R.styleable.AppBarLayout_Layout_layout_scrollInterpolator))
        this.mScrollInterpolator = AnimationUtils.loadInterpolator(param1Context, typedArray.getResourceId(R.styleable.AppBarLayout_Layout_layout_scrollInterpolator, 0)); 
      typedArray.recycle();
    }
    
    @TargetApi(19)
    @RequiresApi(19)
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.mScrollFlags = param1LayoutParams.mScrollFlags;
      this.mScrollInterpolator = param1LayoutParams.mScrollInterpolator;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    @TargetApi(19)
    @RequiresApi(19)
    public LayoutParams(LinearLayout.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public int getScrollFlags() {
      return this.mScrollFlags;
    }
    
    public Interpolator getScrollInterpolator() {
      return this.mScrollInterpolator;
    }
    
    boolean isCollapsible() {
      return ((this.mScrollFlags & 0x1) == 1 && (this.mScrollFlags & 0xA) != 0);
    }
    
    public void setScrollFlags(int param1Int) {
      this.mScrollFlags = param1Int;
    }
    
    public void setScrollInterpolator(Interpolator param1Interpolator) {
      this.mScrollInterpolator = param1Interpolator;
    }
    
    @Retention(RetentionPolicy.SOURCE)
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static @interface ScrollFlags {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ScrollFlags {}
  
  public static interface OnOffsetChangedListener {
    void onOffsetChanged(AppBarLayout param1AppBarLayout, int param1Int);
  }
  
  public static class ScrollingViewBehavior extends HeaderScrollingViewBehavior {
    public ScrollingViewBehavior() {}
    
    public ScrollingViewBehavior(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.ScrollingViewBehavior_Layout);
      setOverlayTop(typedArray.getDimensionPixelSize(R.styleable.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
      typedArray.recycle();
    }
    
    private static int getAppBarLayoutOffset(AppBarLayout param1AppBarLayout) {
      CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams)param1AppBarLayout.getLayoutParams()).getBehavior();
      return (behavior instanceof AppBarLayout.Behavior) ? ((AppBarLayout.Behavior)behavior).getTopBottomOffsetForScrollingSibling() : 0;
    }
    
    private void offsetChildAsNeeded(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      CoordinatorLayout.Behavior behavior = ((CoordinatorLayout.LayoutParams)param1View2.getLayoutParams()).getBehavior();
      if (behavior instanceof AppBarLayout.Behavior) {
        behavior = behavior;
        int i = param1View2.getBottom();
        int j = param1View1.getTop();
        ViewCompat.offsetTopAndBottom(param1View1, ((AppBarLayout.Behavior)behavior).mOffsetDelta + i - j + getVerticalLayoutGap() - getOverlapPixelsForOffset(param1View2));
      } 
    }
    
    AppBarLayout findFirstDependency(List<View> param1List) {
      int j = param1List.size();
      for (int i = 0; i < j; i++) {
        View view = param1List.get(i);
        if (view instanceof AppBarLayout)
          return (AppBarLayout)view; 
      } 
      return null;
    }
    
    float getOverlapRatioForOffset(View param1View) {
      if (param1View instanceof AppBarLayout) {
        AppBarLayout appBarLayout = (AppBarLayout)param1View;
        int j = appBarLayout.getTotalScrollRange();
        int k = appBarLayout.getDownNestedPreScrollRange();
        int i = getAppBarLayoutOffset(appBarLayout);
        if (k == 0 || j + i > k) {
          j -= k;
          if (j != 0)
            return 1.0F + i / j; 
        } 
      } 
      return 0.0F;
    }
    
    int getScrollRange(View param1View) {
      return (param1View instanceof AppBarLayout) ? ((AppBarLayout)param1View).getTotalScrollRange() : super.getScrollRange(param1View);
    }
    
    public boolean layoutDependsOn(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      return param1View2 instanceof AppBarLayout;
    }
    
    public boolean onDependentViewChanged(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      offsetChildAsNeeded(param1CoordinatorLayout, param1View1, param1View2);
      return false;
    }
    
    public boolean onRequestChildRectangleOnScreen(CoordinatorLayout param1CoordinatorLayout, View param1View, Rect param1Rect, boolean param1Boolean) {
      AppBarLayout appBarLayout = findFirstDependency(param1CoordinatorLayout.getDependencies(param1View));
      if (appBarLayout != null) {
        param1Rect.offset(param1View.getLeft(), param1View.getTop());
        Rect rect = this.mTempRect1;
        rect.set(0, 0, param1CoordinatorLayout.getWidth(), param1CoordinatorLayout.getHeight());
        if (!rect.contains(param1Rect)) {
          if (!param1Boolean) {
            param1Boolean = true;
            appBarLayout.setExpanded(false, param1Boolean);
            return true;
          } 
          param1Boolean = false;
          appBarLayout.setExpanded(false, param1Boolean);
          return true;
        } 
      } 
      return false;
    }
  }
}
