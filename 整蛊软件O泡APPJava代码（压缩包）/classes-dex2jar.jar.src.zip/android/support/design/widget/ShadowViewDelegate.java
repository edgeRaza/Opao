package android.support.design.widget;

import android.graphics.drawable.Drawable;

interface ShadowViewDelegate {
  float getRadius();
  
  boolean isCompatPaddingEnabled();
  
  void setBackgroundDrawable(Drawable paramDrawable);
  
  void setShadowPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}
