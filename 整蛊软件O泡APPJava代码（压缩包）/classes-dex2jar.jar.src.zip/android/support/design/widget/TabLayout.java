package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.annotation.StringRes;
import android.support.design.R;
import android.support.v4.util.Pools;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.PointerIconCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.DecorView;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.appcompat.R;
import android.support.v7.content.res.AppCompatResources;
import android.text.Layout;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;

@DecorView
public class TabLayout extends HorizontalScrollView {
  private static final int ANIMATION_DURATION = 300;
  
  static final int DEFAULT_GAP_TEXT_ICON = 8;
  
  private static final int DEFAULT_HEIGHT = 48;
  
  private static final int DEFAULT_HEIGHT_WITH_TEXT_ICON = 72;
  
  static final int FIXED_WRAP_GUTTER_MIN = 16;
  
  public static final int GRAVITY_CENTER = 1;
  
  public static final int GRAVITY_FILL = 0;
  
  private static final int INVALID_WIDTH = -1;
  
  public static final int MODE_FIXED = 1;
  
  public static final int MODE_SCROLLABLE = 0;
  
  static final int MOTION_NON_ADJACENT_OFFSET = 24;
  
  private static final int TAB_MIN_WIDTH_MARGIN = 56;
  
  private static final Pools.Pool<Tab> sTabPool = (Pools.Pool<Tab>)new Pools.SynchronizedPool(16);
  
  private AdapterChangeListener mAdapterChangeListener;
  
  private int mContentInsetStart;
  
  private OnTabSelectedListener mCurrentVpSelectedListener;
  
  int mMode;
  
  private TabLayoutOnPageChangeListener mPageChangeListener;
  
  private PagerAdapter mPagerAdapter;
  
  private DataSetObserver mPagerAdapterObserver;
  
  private final int mRequestedTabMaxWidth;
  
  private final int mRequestedTabMinWidth;
  
  private ValueAnimatorCompat mScrollAnimator;
  
  private final int mScrollableTabMinWidth;
  
  private OnTabSelectedListener mSelectedListener;
  
  private final ArrayList<OnTabSelectedListener> mSelectedListeners;
  
  private Tab mSelectedTab;
  
  private boolean mSetupViewPagerImplicitly;
  
  final int mTabBackgroundResId;
  
  int mTabGravity;
  
  int mTabMaxWidth;
  
  int mTabPaddingBottom;
  
  int mTabPaddingEnd;
  
  int mTabPaddingStart;
  
  int mTabPaddingTop;
  
  private final SlidingTabStrip mTabStrip;
  
  int mTabTextAppearance;
  
  ColorStateList mTabTextColors;
  
  float mTabTextMultiLineSize;
  
  float mTabTextSize;
  
  private final Pools.Pool<TabView> mTabViewPool;
  
  private final ArrayList<Tab> mTabs;
  
  ViewPager mViewPager;
  
  public TabLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public TabLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public TabLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Resources resources;
    this.mTabs = new ArrayList<Tab>();
    this.mTabMaxWidth = Integer.MAX_VALUE;
    this.mSelectedListeners = new ArrayList<OnTabSelectedListener>();
    this.mTabViewPool = (Pools.Pool<TabView>)new Pools.SimplePool(12);
    ThemeUtils.checkAppCompatTheme(paramContext);
    setHorizontalScrollBarEnabled(false);
    this.mTabStrip = new SlidingTabStrip(paramContext);
    super.addView((View)this.mTabStrip, 0, (ViewGroup.LayoutParams)new FrameLayout.LayoutParams(-2, -1));
    null = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.TabLayout, paramInt, R.style.Widget_Design_TabLayout);
    this.mTabStrip.setSelectedIndicatorHeight(null.getDimensionPixelSize(R.styleable.TabLayout_tabIndicatorHeight, 0));
    this.mTabStrip.setSelectedIndicatorColor(null.getColor(R.styleable.TabLayout_tabIndicatorColor, 0));
    paramInt = null.getDimensionPixelSize(R.styleable.TabLayout_tabPadding, 0);
    this.mTabPaddingBottom = paramInt;
    this.mTabPaddingEnd = paramInt;
    this.mTabPaddingTop = paramInt;
    this.mTabPaddingStart = paramInt;
    this.mTabPaddingStart = null.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingStart, this.mTabPaddingStart);
    this.mTabPaddingTop = null.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingTop, this.mTabPaddingTop);
    this.mTabPaddingEnd = null.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingEnd, this.mTabPaddingEnd);
    this.mTabPaddingBottom = null.getDimensionPixelSize(R.styleable.TabLayout_tabPaddingBottom, this.mTabPaddingBottom);
    this.mTabTextAppearance = null.getResourceId(R.styleable.TabLayout_tabTextAppearance, R.style.TextAppearance_Design_Tab);
    TypedArray typedArray = paramContext.obtainStyledAttributes(this.mTabTextAppearance, R.styleable.TextAppearance);
    try {
      this.mTabTextSize = typedArray.getDimensionPixelSize(R.styleable.TextAppearance_android_textSize, 0);
      this.mTabTextColors = typedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
      typedArray.recycle();
      if (null.hasValue(R.styleable.TabLayout_tabTextColor))
        this.mTabTextColors = null.getColorStateList(R.styleable.TabLayout_tabTextColor); 
      if (null.hasValue(R.styleable.TabLayout_tabSelectedTextColor)) {
        paramInt = null.getColor(R.styleable.TabLayout_tabSelectedTextColor, 0);
        this.mTabTextColors = createColorStateList(this.mTabTextColors.getDefaultColor(), paramInt);
      } 
      this.mRequestedTabMinWidth = null.getDimensionPixelSize(R.styleable.TabLayout_tabMinWidth, -1);
      this.mRequestedTabMaxWidth = null.getDimensionPixelSize(R.styleable.TabLayout_tabMaxWidth, -1);
      this.mTabBackgroundResId = null.getResourceId(R.styleable.TabLayout_tabBackground, 0);
      this.mContentInsetStart = null.getDimensionPixelSize(R.styleable.TabLayout_tabContentStart, 0);
      this.mMode = null.getInt(R.styleable.TabLayout_tabMode, 1);
      this.mTabGravity = null.getInt(R.styleable.TabLayout_tabGravity, 0);
      null.recycle();
      resources = getResources();
      this.mTabTextMultiLineSize = resources.getDimensionPixelSize(R.dimen.design_tab_text_size_2line);
      this.mScrollableTabMinWidth = resources.getDimensionPixelSize(R.dimen.design_tab_scrollable_min_width);
      return;
    } finally {
      resources.recycle();
    } 
  }
  
  private void addTabFromItemView(@NonNull TabItem paramTabItem) {
    Tab tab = newTab();
    if (paramTabItem.mText != null)
      tab.setText(paramTabItem.mText); 
    if (paramTabItem.mIcon != null)
      tab.setIcon(paramTabItem.mIcon); 
    if (paramTabItem.mCustomLayout != 0)
      tab.setCustomView(paramTabItem.mCustomLayout); 
    if (!TextUtils.isEmpty(paramTabItem.getContentDescription()))
      tab.setContentDescription(paramTabItem.getContentDescription()); 
    addTab(tab);
  }
  
  private void addTabView(Tab paramTab) {
    TabView tabView = paramTab.mView;
    this.mTabStrip.addView((View)tabView, paramTab.getPosition(), (ViewGroup.LayoutParams)createLayoutParamsForTabs());
  }
  
  private void addViewInternal(View paramView) {
    if (paramView instanceof TabItem) {
      addTabFromItemView((TabItem)paramView);
      return;
    } 
    throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
  }
  
  private void animateToTab(int paramInt) {
    if (paramInt == -1)
      return; 
    if (getWindowToken() == null || !ViewCompat.isLaidOut((View)this) || this.mTabStrip.childrenNeedLayout()) {
      setScrollPosition(paramInt, 0.0F, true);
      return;
    } 
    int i = getScrollX();
    int j = calculateScrollXForTab(paramInt, 0.0F);
    if (i != j) {
      ensureScrollAnimator();
      this.mScrollAnimator.setIntValues(i, j);
      this.mScrollAnimator.start();
    } 
    this.mTabStrip.animateIndicatorToPosition(paramInt, 300);
  }
  
  private void applyModeAndGravity() {
    boolean bool;
    if (this.mMode == 0) {
      bool = Math.max(0, this.mContentInsetStart - this.mTabPaddingStart);
    } else {
      bool = false;
    } 
    ViewCompat.setPaddingRelative((View)this.mTabStrip, bool, 0, 0, 0);
    switch (this.mMode) {
      default:
        updateTabViews(true);
        return;
      case 1:
        this.mTabStrip.setGravity(1);
      case 0:
        break;
    } 
    this.mTabStrip.setGravity(8388611);
  }
  
  private int calculateScrollXForTab(int paramInt, float paramFloat) {
    int i = 0;
    int j = 0;
    if (this.mMode == 0) {
      View view1;
      View view2 = this.mTabStrip.getChildAt(paramInt);
      if (paramInt + 1 < this.mTabStrip.getChildCount()) {
        view1 = this.mTabStrip.getChildAt(paramInt + 1);
      } else {
        view1 = null;
      } 
      if (view2 != null) {
        paramInt = view2.getWidth();
      } else {
        paramInt = 0;
      } 
      i = j;
      if (view1 != null)
        i = view1.getWidth(); 
      j = view2.getLeft() + paramInt / 2 - getWidth() / 2;
      paramInt = (int)((i + paramInt) * 0.5F * paramFloat);
      if (ViewCompat.getLayoutDirection((View)this) == 0)
        return paramInt + j; 
    } else {
      return i;
    } 
    return j - paramInt;
  }
  
  private void configureTab(Tab paramTab, int paramInt) {
    paramTab.setPosition(paramInt);
    this.mTabs.add(paramInt, paramTab);
    int i = this.mTabs.size();
    while (++paramInt < i) {
      ((Tab)this.mTabs.get(paramInt)).setPosition(paramInt);
      paramInt++;
    } 
  }
  
  private static ColorStateList createColorStateList(int paramInt1, int paramInt2) {
    return new ColorStateList(new int[][] { SELECTED_STATE_SET, EMPTY_STATE_SET }, new int[] { paramInt2, paramInt1 });
  }
  
  private LinearLayout.LayoutParams createLayoutParamsForTabs() {
    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
    updateTabViewLayoutParams(layoutParams);
    return layoutParams;
  }
  
  private TabView createTabView(@NonNull Tab paramTab) {
    TabView tabView1;
    if (this.mTabViewPool != null) {
      tabView1 = (TabView)this.mTabViewPool.acquire();
    } else {
      tabView1 = null;
    } 
    TabView tabView2 = tabView1;
    if (tabView1 == null)
      tabView2 = new TabView(getContext()); 
    tabView2.setTab(paramTab);
    tabView2.setFocusable(true);
    tabView2.setMinimumWidth(getTabMinWidth());
    return tabView2;
  }
  
  private void dispatchTabReselected(@NonNull Tab paramTab) {
    for (int i = this.mSelectedListeners.size() - 1; i >= 0; i--)
      ((OnTabSelectedListener)this.mSelectedListeners.get(i)).onTabReselected(paramTab); 
  }
  
  private void dispatchTabSelected(@NonNull Tab paramTab) {
    for (int i = this.mSelectedListeners.size() - 1; i >= 0; i--)
      ((OnTabSelectedListener)this.mSelectedListeners.get(i)).onTabSelected(paramTab); 
  }
  
  private void dispatchTabUnselected(@NonNull Tab paramTab) {
    for (int i = this.mSelectedListeners.size() - 1; i >= 0; i--)
      ((OnTabSelectedListener)this.mSelectedListeners.get(i)).onTabUnselected(paramTab); 
  }
  
  private void ensureScrollAnimator() {
    if (this.mScrollAnimator == null) {
      this.mScrollAnimator = ViewUtils.createAnimator();
      this.mScrollAnimator.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
      this.mScrollAnimator.setDuration(300L);
      this.mScrollAnimator.addUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimatorCompat param1ValueAnimatorCompat) {
              TabLayout.this.scrollTo(param1ValueAnimatorCompat.getAnimatedIntValue(), 0);
            }
          });
    } 
  }
  
  private int getDefaultHeight() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mTabs : Ljava/util/ArrayList;
    //   4: invokevirtual size : ()I
    //   7: istore_2
    //   8: iconst_0
    //   9: istore_1
    //   10: iload_1
    //   11: iload_2
    //   12: if_icmpge -> 67
    //   15: aload_0
    //   16: getfield mTabs : Ljava/util/ArrayList;
    //   19: iload_1
    //   20: invokevirtual get : (I)Ljava/lang/Object;
    //   23: checkcast android/support/design/widget/TabLayout$Tab
    //   26: astore_3
    //   27: aload_3
    //   28: ifnull -> 57
    //   31: aload_3
    //   32: invokevirtual getIcon : ()Landroid/graphics/drawable/Drawable;
    //   35: ifnull -> 57
    //   38: aload_3
    //   39: invokevirtual getText : ()Ljava/lang/CharSequence;
    //   42: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   45: ifne -> 57
    //   48: iconst_1
    //   49: istore_1
    //   50: iload_1
    //   51: ifeq -> 64
    //   54: bipush #72
    //   56: ireturn
    //   57: iload_1
    //   58: iconst_1
    //   59: iadd
    //   60: istore_1
    //   61: goto -> 10
    //   64: bipush #48
    //   66: ireturn
    //   67: iconst_0
    //   68: istore_1
    //   69: goto -> 50
  }
  
  private float getScrollPosition() {
    return this.mTabStrip.getIndicatorPosition();
  }
  
  private int getTabMinWidth() {
    return (this.mRequestedTabMinWidth != -1) ? this.mRequestedTabMinWidth : ((this.mMode == 0) ? this.mScrollableTabMinWidth : 0);
  }
  
  private int getTabScrollRange() {
    return Math.max(0, this.mTabStrip.getWidth() - getWidth() - getPaddingLeft() - getPaddingRight());
  }
  
  private void removeTabViewAt(int paramInt) {
    TabView tabView = (TabView)this.mTabStrip.getChildAt(paramInt);
    this.mTabStrip.removeViewAt(paramInt);
    if (tabView != null) {
      tabView.reset();
      this.mTabViewPool.release(tabView);
    } 
    requestLayout();
  }
  
  private void setSelectedTabView(int paramInt) {
    int i = this.mTabStrip.getChildCount();
    if (paramInt < i)
      for (int j = 0; j < i; j++) {
        boolean bool;
        View view = this.mTabStrip.getChildAt(j);
        if (j == paramInt) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      }  
  }
  
  private void setupWithViewPager(@Nullable ViewPager paramViewPager, boolean paramBoolean1, boolean paramBoolean2) {
    if (this.mViewPager != null) {
      if (this.mPageChangeListener != null)
        this.mViewPager.removeOnPageChangeListener(this.mPageChangeListener); 
      if (this.mAdapterChangeListener != null)
        this.mViewPager.removeOnAdapterChangeListener(this.mAdapterChangeListener); 
    } 
    if (this.mCurrentVpSelectedListener != null) {
      removeOnTabSelectedListener(this.mCurrentVpSelectedListener);
      this.mCurrentVpSelectedListener = null;
    } 
    if (paramViewPager != null) {
      this.mViewPager = paramViewPager;
      if (this.mPageChangeListener == null)
        this.mPageChangeListener = new TabLayoutOnPageChangeListener(this); 
      this.mPageChangeListener.reset();
      paramViewPager.addOnPageChangeListener(this.mPageChangeListener);
      this.mCurrentVpSelectedListener = new ViewPagerOnTabSelectedListener(paramViewPager);
      addOnTabSelectedListener(this.mCurrentVpSelectedListener);
      PagerAdapter pagerAdapter = paramViewPager.getAdapter();
      if (pagerAdapter != null)
        setPagerAdapter(pagerAdapter, paramBoolean1); 
      if (this.mAdapterChangeListener == null)
        this.mAdapterChangeListener = new AdapterChangeListener(); 
      this.mAdapterChangeListener.setAutoRefresh(paramBoolean1);
      paramViewPager.addOnAdapterChangeListener(this.mAdapterChangeListener);
      setScrollPosition(paramViewPager.getCurrentItem(), 0.0F, true);
    } else {
      this.mViewPager = null;
      setPagerAdapter((PagerAdapter)null, false);
    } 
    this.mSetupViewPagerImplicitly = paramBoolean2;
  }
  
  private void updateAllTabs() {
    int j = this.mTabs.size();
    for (int i = 0; i < j; i++)
      ((Tab)this.mTabs.get(i)).updateView(); 
  }
  
  private void updateTabViewLayoutParams(LinearLayout.LayoutParams paramLayoutParams) {
    if (this.mMode == 1 && this.mTabGravity == 0) {
      paramLayoutParams.width = 0;
      paramLayoutParams.weight = 1.0F;
      return;
    } 
    paramLayoutParams.width = -2;
    paramLayoutParams.weight = 0.0F;
  }
  
  public void addOnTabSelectedListener(@NonNull OnTabSelectedListener paramOnTabSelectedListener) {
    if (!this.mSelectedListeners.contains(paramOnTabSelectedListener))
      this.mSelectedListeners.add(paramOnTabSelectedListener); 
  }
  
  public void addTab(@NonNull Tab paramTab) {
    addTab(paramTab, this.mTabs.isEmpty());
  }
  
  public void addTab(@NonNull Tab paramTab, int paramInt) {
    addTab(paramTab, paramInt, this.mTabs.isEmpty());
  }
  
  public void addTab(@NonNull Tab paramTab, int paramInt, boolean paramBoolean) {
    if (paramTab.mParent != this)
      throw new IllegalArgumentException("Tab belongs to a different TabLayout."); 
    configureTab(paramTab, paramInt);
    addTabView(paramTab);
    if (paramBoolean)
      paramTab.select(); 
  }
  
  public void addTab(@NonNull Tab paramTab, boolean paramBoolean) {
    addTab(paramTab, this.mTabs.size(), paramBoolean);
  }
  
  public void addView(View paramView) {
    addViewInternal(paramView);
  }
  
  public void addView(View paramView, int paramInt) {
    addViewInternal(paramView);
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    addViewInternal(paramView);
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    addViewInternal(paramView);
  }
  
  public void clearOnTabSelectedListeners() {
    this.mSelectedListeners.clear();
  }
  
  int dpToPx(int paramInt) {
    return Math.round((getResources().getDisplayMetrics()).density * paramInt);
  }
  
  public FrameLayout.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return generateDefaultLayoutParams();
  }
  
  public int getSelectedTabPosition() {
    return (this.mSelectedTab != null) ? this.mSelectedTab.getPosition() : -1;
  }
  
  @Nullable
  public Tab getTabAt(int paramInt) {
    return (paramInt < 0 || paramInt >= getTabCount()) ? null : this.mTabs.get(paramInt);
  }
  
  public int getTabCount() {
    return this.mTabs.size();
  }
  
  public int getTabGravity() {
    return this.mTabGravity;
  }
  
  int getTabMaxWidth() {
    return this.mTabMaxWidth;
  }
  
  public int getTabMode() {
    return this.mMode;
  }
  
  @Nullable
  public ColorStateList getTabTextColors() {
    return this.mTabTextColors;
  }
  
  @NonNull
  public Tab newTab() {
    Tab tab2 = (Tab)sTabPool.acquire();
    Tab tab1 = tab2;
    if (tab2 == null)
      tab1 = new Tab(); 
    tab1.mParent = this;
    tab1.mView = createTabView(tab1);
    return tab1;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.mViewPager == null) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ViewPager)
        setupWithViewPager((ViewPager)viewParent, true, true); 
    } 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.mSetupViewPagerImplicitly) {
      setupWithViewPager((ViewPager)null);
      this.mSetupViewPagerImplicitly = false;
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    View view;
    boolean bool = true;
    int i = dpToPx(getDefaultHeight()) + getPaddingTop() + getPaddingBottom();
    switch (View.MeasureSpec.getMode(paramInt2)) {
      default:
        i = View.MeasureSpec.getSize(paramInt1);
        if (View.MeasureSpec.getMode(paramInt1) != 0) {
          if (this.mRequestedTabMaxWidth > 0) {
            i = this.mRequestedTabMaxWidth;
          } else {
            i -= dpToPx(56);
          } 
          this.mTabMaxWidth = i;
        } 
        super.onMeasure(paramInt1, paramInt2);
        if (getChildCount() == 1) {
          view = getChildAt(0);
          switch (this.mMode) {
            default:
              paramInt1 = 0;
              if (paramInt1 != 0) {
                paramInt1 = getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom(), (view.getLayoutParams()).height);
                view.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), paramInt1);
              } 
              return;
            case 0:
              if (view.getMeasuredWidth() < getMeasuredWidth()) {
                paramInt1 = 1;
              } else {
                paramInt1 = 0;
              } 
              if (paramInt1 != 0) {
                paramInt1 = getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom(), (view.getLayoutParams()).height);
                view.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), paramInt1);
              } 
              return;
            case 1:
              break;
          } 
          break;
        } 
        return;
      case -2147483648:
        paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(i, View.MeasureSpec.getSize(paramInt2)), 1073741824);
      case 0:
        paramInt2 = View.MeasureSpec.makeMeasureSpec(i, 1073741824);
    } 
    if (view.getMeasuredWidth() != getMeasuredWidth()) {
      paramInt1 = bool;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0) {
      paramInt1 = getChildMeasureSpec(paramInt2, getPaddingTop() + getPaddingBottom(), (view.getLayoutParams()).height);
      view.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), paramInt1);
    } 
  }
  
  void populateFromPagerAdapter() {
    removeAllTabs();
    if (this.mPagerAdapter != null) {
      int j = this.mPagerAdapter.getCount();
      int i;
      for (i = 0; i < j; i++)
        addTab(newTab().setText(this.mPagerAdapter.getPageTitle(i)), false); 
      if (this.mViewPager != null && j > 0) {
        i = this.mViewPager.getCurrentItem();
        if (i != getSelectedTabPosition() && i < getTabCount())
          selectTab(getTabAt(i)); 
      } 
    } 
  }
  
  public void removeAllTabs() {
    for (int i = this.mTabStrip.getChildCount() - 1; i >= 0; i--)
      removeTabViewAt(i); 
    Iterator<Tab> iterator = this.mTabs.iterator();
    while (iterator.hasNext()) {
      Tab tab = iterator.next();
      iterator.remove();
      tab.reset();
      sTabPool.release(tab);
    } 
    this.mSelectedTab = null;
  }
  
  public void removeOnTabSelectedListener(@NonNull OnTabSelectedListener paramOnTabSelectedListener) {
    this.mSelectedListeners.remove(paramOnTabSelectedListener);
  }
  
  public void removeTab(Tab paramTab) {
    if (paramTab.mParent != this)
      throw new IllegalArgumentException("Tab does not belong to this TabLayout."); 
    removeTabAt(paramTab.getPosition());
  }
  
  public void removeTabAt(int paramInt) {
    int i;
    if (this.mSelectedTab != null) {
      i = this.mSelectedTab.getPosition();
    } else {
      i = 0;
    } 
    removeTabViewAt(paramInt);
    Tab tab = this.mTabs.remove(paramInt);
    if (tab != null) {
      tab.reset();
      sTabPool.release(tab);
    } 
    int k = this.mTabs.size();
    for (int j = paramInt; j < k; j++)
      ((Tab)this.mTabs.get(j)).setPosition(j); 
    if (i == paramInt) {
      if (this.mTabs.isEmpty()) {
        tab = null;
      } else {
        tab = this.mTabs.get(Math.max(0, paramInt - 1));
      } 
      selectTab(tab);
    } 
  }
  
  void selectTab(Tab paramTab) {
    selectTab(paramTab, true);
  }
  
  void selectTab(Tab paramTab, boolean paramBoolean) {
    byte b;
    Tab tab = this.mSelectedTab;
    if (tab == paramTab) {
      if (tab != null) {
        dispatchTabReselected(paramTab);
        animateToTab(paramTab.getPosition());
      } 
      return;
    } 
    if (paramTab != null) {
      b = paramTab.getPosition();
    } else {
      b = -1;
    } 
    if (paramBoolean) {
      if ((tab == null || tab.getPosition() == -1) && b != -1) {
        setScrollPosition(b, 0.0F, true);
      } else {
        animateToTab(b);
      } 
      if (b != -1)
        setSelectedTabView(b); 
    } 
    if (tab != null)
      dispatchTabUnselected(tab); 
    this.mSelectedTab = paramTab;
    if (paramTab != null) {
      dispatchTabSelected(paramTab);
      return;
    } 
  }
  
  @Deprecated
  public void setOnTabSelectedListener(@Nullable OnTabSelectedListener paramOnTabSelectedListener) {
    if (this.mSelectedListener != null)
      removeOnTabSelectedListener(this.mSelectedListener); 
    this.mSelectedListener = paramOnTabSelectedListener;
    if (paramOnTabSelectedListener != null)
      addOnTabSelectedListener(paramOnTabSelectedListener); 
  }
  
  void setPagerAdapter(@Nullable PagerAdapter paramPagerAdapter, boolean paramBoolean) {
    if (this.mPagerAdapter != null && this.mPagerAdapterObserver != null)
      this.mPagerAdapter.unregisterDataSetObserver(this.mPagerAdapterObserver); 
    this.mPagerAdapter = paramPagerAdapter;
    if (paramBoolean && paramPagerAdapter != null) {
      if (this.mPagerAdapterObserver == null)
        this.mPagerAdapterObserver = new PagerAdapterObserver(); 
      paramPagerAdapter.registerDataSetObserver(this.mPagerAdapterObserver);
    } 
    populateFromPagerAdapter();
  }
  
  void setScrollAnimatorListener(ValueAnimatorCompat.AnimatorListener paramAnimatorListener) {
    ensureScrollAnimator();
    this.mScrollAnimator.addListener(paramAnimatorListener);
  }
  
  public void setScrollPosition(int paramInt, float paramFloat, boolean paramBoolean) {
    setScrollPosition(paramInt, paramFloat, paramBoolean, true);
  }
  
  void setScrollPosition(int paramInt, float paramFloat, boolean paramBoolean1, boolean paramBoolean2) {
    int i = Math.round(paramInt + paramFloat);
    if (i >= 0 && i < this.mTabStrip.getChildCount()) {
      if (paramBoolean2)
        this.mTabStrip.setIndicatorPositionFromTabPosition(paramInt, paramFloat); 
      if (this.mScrollAnimator != null && this.mScrollAnimator.isRunning())
        this.mScrollAnimator.cancel(); 
      scrollTo(calculateScrollXForTab(paramInt, paramFloat), 0);
      if (paramBoolean1) {
        setSelectedTabView(i);
        return;
      } 
    } 
  }
  
  public void setSelectedTabIndicatorColor(@ColorInt int paramInt) {
    this.mTabStrip.setSelectedIndicatorColor(paramInt);
  }
  
  public void setSelectedTabIndicatorHeight(int paramInt) {
    this.mTabStrip.setSelectedIndicatorHeight(paramInt);
  }
  
  public void setTabGravity(int paramInt) {
    if (this.mTabGravity != paramInt) {
      this.mTabGravity = paramInt;
      applyModeAndGravity();
    } 
  }
  
  public void setTabMode(int paramInt) {
    if (paramInt != this.mMode) {
      this.mMode = paramInt;
      applyModeAndGravity();
    } 
  }
  
  public void setTabTextColors(int paramInt1, int paramInt2) {
    setTabTextColors(createColorStateList(paramInt1, paramInt2));
  }
  
  public void setTabTextColors(@Nullable ColorStateList paramColorStateList) {
    if (this.mTabTextColors != paramColorStateList) {
      this.mTabTextColors = paramColorStateList;
      updateAllTabs();
    } 
  }
  
  @Deprecated
  public void setTabsFromPagerAdapter(@Nullable PagerAdapter paramPagerAdapter) {
    setPagerAdapter(paramPagerAdapter, false);
  }
  
  public void setupWithViewPager(@Nullable ViewPager paramViewPager) {
    setupWithViewPager(paramViewPager, true);
  }
  
  public void setupWithViewPager(@Nullable ViewPager paramViewPager, boolean paramBoolean) {
    setupWithViewPager(paramViewPager, paramBoolean, false);
  }
  
  public boolean shouldDelayChildPressedState() {
    return (getTabScrollRange() > 0);
  }
  
  void updateTabViews(boolean paramBoolean) {
    for (int i = 0; i < this.mTabStrip.getChildCount(); i++) {
      View view = this.mTabStrip.getChildAt(i);
      view.setMinimumWidth(getTabMinWidth());
      updateTabViewLayoutParams((LinearLayout.LayoutParams)view.getLayoutParams());
      if (paramBoolean)
        view.requestLayout(); 
    } 
  }
  
  private class AdapterChangeListener implements ViewPager.OnAdapterChangeListener {
    private boolean mAutoRefresh;
    
    public void onAdapterChanged(@NonNull ViewPager param1ViewPager, @Nullable PagerAdapter param1PagerAdapter1, @Nullable PagerAdapter param1PagerAdapter2) {
      if (TabLayout.this.mViewPager == param1ViewPager)
        TabLayout.this.setPagerAdapter(param1PagerAdapter2, this.mAutoRefresh); 
    }
    
    void setAutoRefresh(boolean param1Boolean) {
      this.mAutoRefresh = param1Boolean;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface Mode {}
  
  public static interface OnTabSelectedListener {
    void onTabReselected(TabLayout.Tab param1Tab);
    
    void onTabSelected(TabLayout.Tab param1Tab);
    
    void onTabUnselected(TabLayout.Tab param1Tab);
  }
  
  private class PagerAdapterObserver extends DataSetObserver {
    public void onChanged() {
      TabLayout.this.populateFromPagerAdapter();
    }
    
    public void onInvalidated() {
      TabLayout.this.populateFromPagerAdapter();
    }
  }
  
  private class SlidingTabStrip extends LinearLayout {
    private ValueAnimatorCompat mIndicatorAnimator;
    
    private int mIndicatorLeft = -1;
    
    private int mIndicatorRight = -1;
    
    private int mSelectedIndicatorHeight;
    
    private final Paint mSelectedIndicatorPaint;
    
    int mSelectedPosition = -1;
    
    float mSelectionOffset;
    
    SlidingTabStrip(Context param1Context) {
      super(param1Context);
      setWillNotDraw(false);
      this.mSelectedIndicatorPaint = new Paint();
    }
    
    private void updateIndicatorPosition() {
      byte b1;
      byte b2;
      View view = getChildAt(this.mSelectedPosition);
      if (view != null && view.getWidth() > 0) {
        int j = view.getLeft();
        int i = view.getRight();
        b1 = i;
        b2 = j;
        if (this.mSelectionOffset > 0.0F) {
          b1 = i;
          b2 = j;
          if (this.mSelectedPosition < getChildCount() - 1) {
            view = getChildAt(this.mSelectedPosition + 1);
            float f1 = this.mSelectionOffset;
            float f2 = view.getLeft();
            float f3 = this.mSelectionOffset;
            b2 = (int)(j * (1.0F - f3) + f1 * f2);
            f1 = this.mSelectionOffset;
            f2 = view.getRight();
            f3 = this.mSelectionOffset;
            b1 = (int)(i * (1.0F - f3) + f2 * f1);
          } 
        } 
      } else {
        b1 = -1;
        b2 = -1;
      } 
      setIndicatorPosition(b2, b1);
    }
    
    void animateIndicatorToPosition(final int position, int param1Int2) {
      final int startLeft;
      final int startRight;
      if (this.mIndicatorAnimator != null && this.mIndicatorAnimator.isRunning())
        this.mIndicatorAnimator.cancel(); 
      if (ViewCompat.getLayoutDirection((View)this) == 1) {
        i = 1;
      } else {
        i = 0;
      } 
      View view = getChildAt(position);
      if (view == null) {
        updateIndicatorPosition();
        return;
      } 
      final int targetLeft = view.getLeft();
      final int targetRight = view.getRight();
      if (Math.abs(position - this.mSelectedPosition) <= 1) {
        i = this.mIndicatorLeft;
        j = this.mIndicatorRight;
      } else {
        j = TabLayout.this.dpToPx(24);
        if (position < this.mSelectedPosition) {
          if (i != 0) {
            j = k - j;
            i = j;
          } else {
            j = m + j;
            i = j;
          } 
        } else if (i != 0) {
          j = m + j;
          i = j;
        } else {
          j = k - j;
          i = j;
        } 
      } 
      if (i != k || j != m) {
        ValueAnimatorCompat valueAnimatorCompat = ViewUtils.createAnimator();
        this.mIndicatorAnimator = valueAnimatorCompat;
        valueAnimatorCompat.setInterpolator(AnimationUtils.FAST_OUT_SLOW_IN_INTERPOLATOR);
        valueAnimatorCompat.setDuration(param1Int2);
        valueAnimatorCompat.setFloatValues(0.0F, 1.0F);
        valueAnimatorCompat.addUpdateListener(new ValueAnimatorCompat.AnimatorUpdateListener() {
              public void onAnimationUpdate(ValueAnimatorCompat param2ValueAnimatorCompat) {
                float f = param2ValueAnimatorCompat.getAnimatedFraction();
                TabLayout.SlidingTabStrip.this.setIndicatorPosition(AnimationUtils.lerp(startLeft, targetLeft, f), AnimationUtils.lerp(startRight, targetRight, f));
              }
            });
        valueAnimatorCompat.addListener(new ValueAnimatorCompat.AnimatorListenerAdapter() {
              public void onAnimationEnd(ValueAnimatorCompat param2ValueAnimatorCompat) {
                TabLayout.SlidingTabStrip.this.mSelectedPosition = position;
                TabLayout.SlidingTabStrip.this.mSelectionOffset = 0.0F;
              }
            });
        valueAnimatorCompat.start();
        return;
      } 
    }
    
    boolean childrenNeedLayout() {
      boolean bool = false;
      int j = getChildCount();
      for (int i = 0;; i++) {
        boolean bool1 = bool;
        if (i < j) {
          if (getChildAt(i).getWidth() <= 0)
            return true; 
        } else {
          return bool1;
        } 
      } 
    }
    
    public void draw(Canvas param1Canvas) {
      super.draw(param1Canvas);
      if (this.mIndicatorLeft >= 0 && this.mIndicatorRight > this.mIndicatorLeft)
        param1Canvas.drawRect(this.mIndicatorLeft, (getHeight() - this.mSelectedIndicatorHeight), this.mIndicatorRight, getHeight(), this.mSelectedIndicatorPaint); 
    }
    
    float getIndicatorPosition() {
      return this.mSelectedPosition + this.mSelectionOffset;
    }
    
    protected void onLayout(boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      super.onLayout(param1Boolean, param1Int1, param1Int2, param1Int3, param1Int4);
      if (this.mIndicatorAnimator != null && this.mIndicatorAnimator.isRunning()) {
        this.mIndicatorAnimator.cancel();
        long l = this.mIndicatorAnimator.getDuration();
        param1Int1 = this.mSelectedPosition;
        float f = this.mIndicatorAnimator.getAnimatedFraction();
        animateIndicatorToPosition(param1Int1, Math.round((float)l * (1.0F - f)));
        return;
      } 
      updateIndicatorPosition();
    }
    
    protected void onMeasure(int param1Int1, int param1Int2) {
      int i = 0;
      super.onMeasure(param1Int1, param1Int2);
      if (View.MeasureSpec.getMode(param1Int1) == 1073741824 && TabLayout.this.mMode == 1 && TabLayout.this.mTabGravity == 1) {
        int k = getChildCount();
        int j = 0;
        byte b = 0;
        while (true) {
          if (j < k) {
            byte b1;
            View view = getChildAt(j);
            if (view.getVisibility() == 0) {
              b1 = Math.max(b, view.getMeasuredWidth());
            } else {
              b1 = b;
            } 
            j++;
            b = b1;
            continue;
          } 
          if (b) {
            int m = TabLayout.this.dpToPx(16);
            if (b * k <= getMeasuredWidth() - m * 2) {
              j = 0;
              m = i;
              while (true) {
                i = m;
                if (j < k) {
                  LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)getChildAt(j).getLayoutParams();
                  if (layoutParams.width != b || layoutParams.weight != 0.0F) {
                    layoutParams.width = b;
                    layoutParams.weight = 0.0F;
                    m = 1;
                  } 
                  j++;
                  continue;
                } 
                break;
              } 
            } else {
              TabLayout.this.mTabGravity = 0;
              TabLayout.this.updateTabViews(false);
              i = 1;
            } 
            if (i != 0) {
              super.onMeasure(param1Int1, param1Int2);
              return;
            } 
          } 
          return;
        } 
      } 
    }
    
    void setIndicatorPosition(int param1Int1, int param1Int2) {
      if (param1Int1 != this.mIndicatorLeft || param1Int2 != this.mIndicatorRight) {
        this.mIndicatorLeft = param1Int1;
        this.mIndicatorRight = param1Int2;
        ViewCompat.postInvalidateOnAnimation((View)this);
      } 
    }
    
    void setIndicatorPositionFromTabPosition(int param1Int, float param1Float) {
      if (this.mIndicatorAnimator != null && this.mIndicatorAnimator.isRunning())
        this.mIndicatorAnimator.cancel(); 
      this.mSelectedPosition = param1Int;
      this.mSelectionOffset = param1Float;
      updateIndicatorPosition();
    }
    
    void setSelectedIndicatorColor(int param1Int) {
      if (this.mSelectedIndicatorPaint.getColor() != param1Int) {
        this.mSelectedIndicatorPaint.setColor(param1Int);
        ViewCompat.postInvalidateOnAnimation((View)this);
      } 
    }
    
    void setSelectedIndicatorHeight(int param1Int) {
      if (this.mSelectedIndicatorHeight != param1Int) {
        this.mSelectedIndicatorHeight = param1Int;
        ViewCompat.postInvalidateOnAnimation((View)this);
      } 
    }
  }
  
  class null implements ValueAnimatorCompat.AnimatorUpdateListener {
    public void onAnimationUpdate(ValueAnimatorCompat param1ValueAnimatorCompat) {
      float f = param1ValueAnimatorCompat.getAnimatedFraction();
      this.this$1.setIndicatorPosition(AnimationUtils.lerp(startLeft, targetLeft, f), AnimationUtils.lerp(startRight, targetRight, f));
    }
  }
  
  class null extends ValueAnimatorCompat.AnimatorListenerAdapter {
    public void onAnimationEnd(ValueAnimatorCompat param1ValueAnimatorCompat) {
      this.this$1.mSelectedPosition = position;
      this.this$1.mSelectionOffset = 0.0F;
    }
  }
  
  public static final class Tab {
    public static final int INVALID_POSITION = -1;
    
    private CharSequence mContentDesc;
    
    private View mCustomView;
    
    private Drawable mIcon;
    
    TabLayout mParent;
    
    private int mPosition = -1;
    
    private Object mTag;
    
    private CharSequence mText;
    
    TabLayout.TabView mView;
    
    @Nullable
    public CharSequence getContentDescription() {
      return this.mContentDesc;
    }
    
    @Nullable
    public View getCustomView() {
      return this.mCustomView;
    }
    
    @Nullable
    public Drawable getIcon() {
      return this.mIcon;
    }
    
    public int getPosition() {
      return this.mPosition;
    }
    
    @Nullable
    public Object getTag() {
      return this.mTag;
    }
    
    @Nullable
    public CharSequence getText() {
      return this.mText;
    }
    
    public boolean isSelected() {
      if (this.mParent == null)
        throw new IllegalArgumentException("Tab not attached to a TabLayout"); 
      return (this.mParent.getSelectedTabPosition() == this.mPosition);
    }
    
    void reset() {
      this.mParent = null;
      this.mView = null;
      this.mTag = null;
      this.mIcon = null;
      this.mText = null;
      this.mContentDesc = null;
      this.mPosition = -1;
      this.mCustomView = null;
    }
    
    public void select() {
      if (this.mParent == null)
        throw new IllegalArgumentException("Tab not attached to a TabLayout"); 
      this.mParent.selectTab(this);
    }
    
    @NonNull
    public Tab setContentDescription(@StringRes int param1Int) {
      if (this.mParent == null)
        throw new IllegalArgumentException("Tab not attached to a TabLayout"); 
      return setContentDescription(this.mParent.getResources().getText(param1Int));
    }
    
    @NonNull
    public Tab setContentDescription(@Nullable CharSequence param1CharSequence) {
      this.mContentDesc = param1CharSequence;
      updateView();
      return this;
    }
    
    @NonNull
    public Tab setCustomView(@LayoutRes int param1Int) {
      return setCustomView(LayoutInflater.from(this.mView.getContext()).inflate(param1Int, (ViewGroup)this.mView, false));
    }
    
    @NonNull
    public Tab setCustomView(@Nullable View param1View) {
      this.mCustomView = param1View;
      updateView();
      return this;
    }
    
    @NonNull
    public Tab setIcon(@DrawableRes int param1Int) {
      if (this.mParent == null)
        throw new IllegalArgumentException("Tab not attached to a TabLayout"); 
      return setIcon(AppCompatResources.getDrawable(this.mParent.getContext(), param1Int));
    }
    
    @NonNull
    public Tab setIcon(@Nullable Drawable param1Drawable) {
      this.mIcon = param1Drawable;
      updateView();
      return this;
    }
    
    void setPosition(int param1Int) {
      this.mPosition = param1Int;
    }
    
    @NonNull
    public Tab setTag(@Nullable Object param1Object) {
      this.mTag = param1Object;
      return this;
    }
    
    @NonNull
    public Tab setText(@StringRes int param1Int) {
      if (this.mParent == null)
        throw new IllegalArgumentException("Tab not attached to a TabLayout"); 
      return setText(this.mParent.getResources().getText(param1Int));
    }
    
    @NonNull
    public Tab setText(@Nullable CharSequence param1CharSequence) {
      this.mText = param1CharSequence;
      updateView();
      return this;
    }
    
    void updateView() {
      if (this.mView != null)
        this.mView.update(); 
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface TabGravity {}
  
  public static class TabLayoutOnPageChangeListener implements ViewPager.OnPageChangeListener {
    private int mPreviousScrollState;
    
    private int mScrollState;
    
    private final WeakReference<TabLayout> mTabLayoutRef;
    
    public TabLayoutOnPageChangeListener(TabLayout param1TabLayout) {
      this.mTabLayoutRef = new WeakReference<TabLayout>(param1TabLayout);
    }
    
    public void onPageScrollStateChanged(int param1Int) {
      this.mPreviousScrollState = this.mScrollState;
      this.mScrollState = param1Int;
    }
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {
      boolean bool = false;
      TabLayout tabLayout = this.mTabLayoutRef.get();
      if (tabLayout != null) {
        boolean bool1;
        if (this.mScrollState != 2 || this.mPreviousScrollState == 1) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (this.mScrollState != 2 || this.mPreviousScrollState != 0)
          bool = true; 
        tabLayout.setScrollPosition(param1Int1, param1Float, bool1, bool);
      } 
    }
    
    public void onPageSelected(int param1Int) {
      TabLayout tabLayout = this.mTabLayoutRef.get();
      if (tabLayout != null && tabLayout.getSelectedTabPosition() != param1Int && param1Int < tabLayout.getTabCount()) {
        boolean bool;
        if (this.mScrollState == 0 || (this.mScrollState == 2 && this.mPreviousScrollState == 0)) {
          bool = true;
        } else {
          bool = false;
        } 
        tabLayout.selectTab(tabLayout.getTabAt(param1Int), bool);
      } 
    }
    
    void reset() {
      this.mScrollState = 0;
      this.mPreviousScrollState = 0;
    }
  }
  
  class TabView extends LinearLayout implements View.OnLongClickListener {
    private ImageView mCustomIconView;
    
    private TextView mCustomTextView;
    
    private View mCustomView;
    
    private int mDefaultMaxLines = 2;
    
    private ImageView mIconView;
    
    private TabLayout.Tab mTab;
    
    private TextView mTextView;
    
    public TabView(Context param1Context) {
      super(param1Context);
      if (TabLayout.this.mTabBackgroundResId != 0)
        ViewCompat.setBackground((View)this, AppCompatResources.getDrawable(param1Context, TabLayout.this.mTabBackgroundResId)); 
      ViewCompat.setPaddingRelative((View)this, TabLayout.this.mTabPaddingStart, TabLayout.this.mTabPaddingTop, TabLayout.this.mTabPaddingEnd, TabLayout.this.mTabPaddingBottom);
      setGravity(17);
      setOrientation(1);
      setClickable(true);
      ViewCompat.setPointerIcon((View)this, PointerIconCompat.getSystemIcon(getContext(), 1002));
    }
    
    private float approximateLineWidth(Layout param1Layout, int param1Int, float param1Float) {
      return param1Layout.getLineWidth(param1Int) * param1Float / param1Layout.getPaint().getTextSize();
    }
    
    private void updateTextAndIcon(@Nullable TextView param1TextView, @Nullable ImageView param1ImageView) {
      boolean bool;
      Drawable drawable;
      CharSequence charSequence1;
      CharSequence charSequence2;
      if (this.mTab != null) {
        drawable = this.mTab.getIcon();
      } else {
        drawable = null;
      } 
      if (this.mTab != null) {
        charSequence1 = this.mTab.getText();
      } else {
        charSequence1 = null;
      } 
      if (this.mTab != null) {
        charSequence2 = this.mTab.getContentDescription();
      } else {
        charSequence2 = null;
      } 
      if (param1ImageView != null) {
        if (drawable != null) {
          param1ImageView.setImageDrawable(drawable);
          param1ImageView.setVisibility(0);
          setVisibility(0);
        } else {
          param1ImageView.setVisibility(8);
          param1ImageView.setImageDrawable(null);
        } 
        param1ImageView.setContentDescription(charSequence2);
      } 
      if (!TextUtils.isEmpty(charSequence1)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1TextView != null) {
        if (bool) {
          param1TextView.setText(charSequence1);
          param1TextView.setVisibility(0);
          setVisibility(0);
        } else {
          param1TextView.setVisibility(8);
          param1TextView.setText(null);
        } 
        param1TextView.setContentDescription(charSequence2);
      } 
      if (param1ImageView != null) {
        boolean bool1;
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)param1ImageView.getLayoutParams();
        if (bool && param1ImageView.getVisibility() == 0) {
          bool1 = TabLayout.this.dpToPx(8);
        } else {
          bool1 = false;
        } 
        if (bool1 != marginLayoutParams.bottomMargin) {
          marginLayoutParams.bottomMargin = bool1;
          param1ImageView.requestLayout();
        } 
      } 
      if (!bool && !TextUtils.isEmpty(charSequence2)) {
        setOnLongClickListener(this);
        return;
      } 
      setOnLongClickListener(null);
      setLongClickable(false);
    }
    
    public TabLayout.Tab getTab() {
      return this.mTab;
    }
    
    @TargetApi(14)
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(ActionBar.Tab.class.getName());
    }
    
    @TargetApi(14)
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName(ActionBar.Tab.class.getName());
    }
    
    public boolean onLongClick(View param1View) {
      int[] arrayOfInt = new int[2];
      Rect rect = new Rect();
      getLocationOnScreen(arrayOfInt);
      getWindowVisibleDisplayFrame(rect);
      Context context = getContext();
      int i = getWidth();
      int k = getHeight();
      int m = arrayOfInt[1];
      int n = k / 2;
      int j = arrayOfInt[0];
      j = i / 2 + j;
      i = j;
      if (ViewCompat.getLayoutDirection(param1View) == 0)
        i = (context.getResources().getDisplayMetrics()).widthPixels - j; 
      Toast toast = Toast.makeText(context, this.mTab.getContentDescription(), 0);
      if (m + n < rect.height()) {
        toast.setGravity(8388661, i, arrayOfInt[1] + k - rect.top);
        toast.show();
        return true;
      } 
      toast.setGravity(81, 0, k);
      toast.show();
      return true;
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      // Byte code:
      //   0: iconst_1
      //   1: istore #7
      //   3: iload_1
      //   4: invokestatic getSize : (I)I
      //   7: istore #6
      //   9: iload_1
      //   10: invokestatic getMode : (I)I
      //   13: istore #8
      //   15: aload_0
      //   16: getfield this$0 : Landroid/support/design/widget/TabLayout;
      //   19: invokevirtual getTabMaxWidth : ()I
      //   22: istore #9
      //   24: iload_1
      //   25: istore #5
      //   27: iload #9
      //   29: ifle -> 62
      //   32: iload #8
      //   34: ifeq -> 47
      //   37: iload_1
      //   38: istore #5
      //   40: iload #6
      //   42: iload #9
      //   44: if_icmple -> 62
      //   47: aload_0
      //   48: getfield this$0 : Landroid/support/design/widget/TabLayout;
      //   51: getfield mTabMaxWidth : I
      //   54: ldc_w -2147483648
      //   57: invokestatic makeMeasureSpec : (II)I
      //   60: istore #5
      //   62: aload_0
      //   63: iload #5
      //   65: iload_2
      //   66: invokespecial onMeasure : (II)V
      //   69: aload_0
      //   70: getfield mTextView : Landroid/widget/TextView;
      //   73: ifnull -> 276
      //   76: aload_0
      //   77: invokevirtual getResources : ()Landroid/content/res/Resources;
      //   80: pop
      //   81: aload_0
      //   82: getfield this$0 : Landroid/support/design/widget/TabLayout;
      //   85: getfield mTabTextSize : F
      //   88: fstore #4
      //   90: aload_0
      //   91: getfield mDefaultMaxLines : I
      //   94: istore #6
      //   96: aload_0
      //   97: getfield mIconView : Landroid/widget/ImageView;
      //   100: ifnull -> 277
      //   103: aload_0
      //   104: getfield mIconView : Landroid/widget/ImageView;
      //   107: invokevirtual getVisibility : ()I
      //   110: ifne -> 277
      //   113: iconst_1
      //   114: istore_1
      //   115: fload #4
      //   117: fstore_3
      //   118: aload_0
      //   119: getfield mTextView : Landroid/widget/TextView;
      //   122: invokevirtual getTextSize : ()F
      //   125: fstore #4
      //   127: aload_0
      //   128: getfield mTextView : Landroid/widget/TextView;
      //   131: invokevirtual getLineCount : ()I
      //   134: istore #8
      //   136: aload_0
      //   137: getfield mTextView : Landroid/widget/TextView;
      //   140: invokestatic getMaxLines : (Landroid/widget/TextView;)I
      //   143: istore #6
      //   145: fload_3
      //   146: fload #4
      //   148: fcmpl
      //   149: ifne -> 163
      //   152: iload #6
      //   154: iflt -> 276
      //   157: iload_1
      //   158: iload #6
      //   160: if_icmpeq -> 276
      //   163: iload #7
      //   165: istore #6
      //   167: aload_0
      //   168: getfield this$0 : Landroid/support/design/widget/TabLayout;
      //   171: getfield mMode : I
      //   174: iconst_1
      //   175: if_icmpne -> 247
      //   178: iload #7
      //   180: istore #6
      //   182: fload_3
      //   183: fload #4
      //   185: fcmpl
      //   186: ifle -> 247
      //   189: iload #7
      //   191: istore #6
      //   193: iload #8
      //   195: iconst_1
      //   196: if_icmpne -> 247
      //   199: aload_0
      //   200: getfield mTextView : Landroid/widget/TextView;
      //   203: invokevirtual getLayout : ()Landroid/text/Layout;
      //   206: astore #10
      //   208: aload #10
      //   210: ifnull -> 244
      //   213: iload #7
      //   215: istore #6
      //   217: aload_0
      //   218: aload #10
      //   220: iconst_0
      //   221: fload_3
      //   222: invokespecial approximateLineWidth : (Landroid/text/Layout;IF)F
      //   225: aload_0
      //   226: invokevirtual getMeasuredWidth : ()I
      //   229: aload_0
      //   230: invokevirtual getPaddingLeft : ()I
      //   233: isub
      //   234: aload_0
      //   235: invokevirtual getPaddingRight : ()I
      //   238: isub
      //   239: i2f
      //   240: fcmpl
      //   241: ifle -> 247
      //   244: iconst_0
      //   245: istore #6
      //   247: iload #6
      //   249: ifeq -> 276
      //   252: aload_0
      //   253: getfield mTextView : Landroid/widget/TextView;
      //   256: iconst_0
      //   257: fload_3
      //   258: invokevirtual setTextSize : (IF)V
      //   261: aload_0
      //   262: getfield mTextView : Landroid/widget/TextView;
      //   265: iload_1
      //   266: invokevirtual setMaxLines : (I)V
      //   269: aload_0
      //   270: iload #5
      //   272: iload_2
      //   273: invokespecial onMeasure : (II)V
      //   276: return
      //   277: iload #6
      //   279: istore_1
      //   280: fload #4
      //   282: fstore_3
      //   283: aload_0
      //   284: getfield mTextView : Landroid/widget/TextView;
      //   287: ifnull -> 118
      //   290: iload #6
      //   292: istore_1
      //   293: fload #4
      //   295: fstore_3
      //   296: aload_0
      //   297: getfield mTextView : Landroid/widget/TextView;
      //   300: invokevirtual getLineCount : ()I
      //   303: iconst_1
      //   304: if_icmple -> 118
      //   307: aload_0
      //   308: getfield this$0 : Landroid/support/design/widget/TabLayout;
      //   311: getfield mTabTextMultiLineSize : F
      //   314: fstore_3
      //   315: iload #6
      //   317: istore_1
      //   318: goto -> 118
    }
    
    public boolean performClick() {
      boolean bool2 = super.performClick();
      boolean bool1 = bool2;
      if (this.mTab != null) {
        if (!bool2)
          playSoundEffect(0); 
        this.mTab.select();
        bool1 = true;
      } 
      return bool1;
    }
    
    void reset() {
      setTab((TabLayout.Tab)null);
      setSelected(false);
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean && Build.VERSION.SDK_INT < 16)
        sendAccessibilityEvent(4); 
      if (this.mTextView != null)
        this.mTextView.setSelected(param1Boolean); 
      if (this.mIconView != null)
        this.mIconView.setSelected(param1Boolean); 
      if (this.mCustomView != null)
        this.mCustomView.setSelected(param1Boolean); 
    }
    
    void setTab(@Nullable TabLayout.Tab param1Tab) {
      if (param1Tab != this.mTab) {
        this.mTab = param1Tab;
        update();
      } 
    }
    
    final void update() {
      boolean bool;
      View view;
      TabLayout.Tab tab = this.mTab;
      if (tab != null) {
        view = tab.getCustomView();
      } else {
        view = null;
      } 
      if (view != null) {
        ViewParent viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.mCustomView = view;
        if (this.mTextView != null)
          this.mTextView.setVisibility(8); 
        if (this.mIconView != null) {
          this.mIconView.setVisibility(8);
          this.mIconView.setImageDrawable(null);
        } 
        this.mCustomTextView = (TextView)view.findViewById(16908308);
        if (this.mCustomTextView != null)
          this.mDefaultMaxLines = TextViewCompat.getMaxLines(this.mCustomTextView); 
        this.mCustomIconView = (ImageView)view.findViewById(16908294);
      } else {
        if (this.mCustomView != null) {
          removeView(this.mCustomView);
          this.mCustomView = null;
        } 
        this.mCustomTextView = null;
        this.mCustomIconView = null;
      } 
      if (this.mCustomView == null) {
        if (this.mIconView == null) {
          ImageView imageView = (ImageView)LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_icon, (ViewGroup)this, false);
          addView((View)imageView, 0);
          this.mIconView = imageView;
        } 
        if (this.mTextView == null) {
          TextView textView = (TextView)LayoutInflater.from(getContext()).inflate(R.layout.design_layout_tab_text, (ViewGroup)this, false);
          addView((View)textView);
          this.mTextView = textView;
          this.mDefaultMaxLines = TextViewCompat.getMaxLines(this.mTextView);
        } 
        TextViewCompat.setTextAppearance(this.mTextView, TabLayout.this.mTabTextAppearance);
        if (TabLayout.this.mTabTextColors != null)
          this.mTextView.setTextColor(TabLayout.this.mTabTextColors); 
        updateTextAndIcon(this.mTextView, this.mIconView);
      } else if (this.mCustomTextView != null || this.mCustomIconView != null) {
        updateTextAndIcon(this.mCustomTextView, this.mCustomIconView);
      } 
      if (tab != null && tab.isSelected()) {
        bool = true;
      } else {
        bool = false;
      } 
      setSelected(bool);
    }
  }
  
  public static class ViewPagerOnTabSelectedListener implements OnTabSelectedListener {
    private final ViewPager mViewPager;
    
    public ViewPagerOnTabSelectedListener(ViewPager param1ViewPager) {
      this.mViewPager = param1ViewPager;
    }
    
    public void onTabReselected(TabLayout.Tab param1Tab) {}
    
    public void onTabSelected(TabLayout.Tab param1Tab) {
      this.mViewPager.setCurrentItem(param1Tab.getPosition());
    }
    
    public void onTabUnselected(TabLayout.Tab param1Tab) {}
  }
}
