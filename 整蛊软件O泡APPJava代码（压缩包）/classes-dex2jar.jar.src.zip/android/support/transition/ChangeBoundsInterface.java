package android.support.transition;

interface ChangeBoundsInterface {
  void setResizeClip(boolean paramBoolean);
}
