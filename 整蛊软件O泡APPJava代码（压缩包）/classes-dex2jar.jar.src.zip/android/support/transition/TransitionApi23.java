package android.support.transition;

import android.annotation.TargetApi;
import android.support.annotation.RequiresApi;

@TargetApi(23)
@RequiresApi(23)
class TransitionApi23 extends TransitionKitKat {
  public TransitionImpl removeTarget(int paramInt) {
    this.mTransition.removeTarget(paramInt);
    return this;
  }
}
