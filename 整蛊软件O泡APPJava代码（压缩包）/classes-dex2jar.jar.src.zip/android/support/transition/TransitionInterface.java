package android.support.transition;

import android.animation.Animator;
import android.view.ViewGroup;

interface TransitionInterface {
  void captureEndValues(TransitionValues paramTransitionValues);
  
  void captureStartValues(TransitionValues paramTransitionValues);
  
  Animator createAnimator(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2);
}
