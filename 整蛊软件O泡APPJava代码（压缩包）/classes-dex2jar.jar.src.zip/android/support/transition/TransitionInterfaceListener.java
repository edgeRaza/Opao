package android.support.transition;

interface TransitionInterfaceListener<TransitionT extends TransitionInterface> {
  void onTransitionCancel(TransitionT paramTransitionT);
  
  void onTransitionEnd(TransitionT paramTransitionT);
  
  void onTransitionPause(TransitionT paramTransitionT);
  
  void onTransitionResume(TransitionT paramTransitionT);
  
  void onTransitionStart(TransitionT paramTransitionT);
}
