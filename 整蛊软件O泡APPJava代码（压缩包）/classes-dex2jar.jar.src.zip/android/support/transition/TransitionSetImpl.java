package android.support.transition;

interface TransitionSetImpl {
  TransitionSetImpl addTransition(TransitionImpl paramTransitionImpl);
  
  int getOrdering();
  
  TransitionSetImpl removeTransition(TransitionImpl paramTransitionImpl);
  
  TransitionSetImpl setOrdering(int paramInt);
}
