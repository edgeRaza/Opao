package android.support.transition;

import android.animation.Animator;
import android.view.ViewGroup;

interface VisibilityImpl {
  boolean isVisible(TransitionValues paramTransitionValues);
  
  Animator onAppear(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, int paramInt1, TransitionValues paramTransitionValues2, int paramInt2);
  
  Animator onDisappear(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, int paramInt1, TransitionValues paramTransitionValues2, int paramInt2);
}
