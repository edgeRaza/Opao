package android.support.transition;

import android.animation.Animator;
import android.annotation.TargetApi;
import android.support.annotation.RequiresApi;
import android.view.View;
import android.view.ViewGroup;

@TargetApi(14)
@RequiresApi(14)
abstract class VisibilityPort extends TransitionPort {
  private static final String PROPNAME_PARENT = "android:visibility:parent";
  
  private static final String PROPNAME_VISIBILITY = "android:visibility:visibility";
  
  private static final String[] sTransitionProperties = new String[] { "android:visibility:visibility", "android:visibility:parent" };
  
  private void captureValues(TransitionValues paramTransitionValues) {
    int i = paramTransitionValues.view.getVisibility();
    paramTransitionValues.values.put("android:visibility:visibility", Integer.valueOf(i));
    paramTransitionValues.values.put("android:visibility:parent", paramTransitionValues.view.getParent());
  }
  
  private VisibilityInfo getVisibilityChangeInfo(TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2) {
    VisibilityInfo visibilityInfo = new VisibilityInfo();
    visibilityInfo.visibilityChange = false;
    visibilityInfo.fadeIn = false;
    if (paramTransitionValues1 != null) {
      visibilityInfo.startVisibility = ((Integer)paramTransitionValues1.values.get("android:visibility:visibility")).intValue();
      visibilityInfo.startParent = (ViewGroup)paramTransitionValues1.values.get("android:visibility:parent");
    } else {
      visibilityInfo.startVisibility = -1;
      visibilityInfo.startParent = null;
    } 
    if (paramTransitionValues2 != null) {
      visibilityInfo.endVisibility = ((Integer)paramTransitionValues2.values.get("android:visibility:visibility")).intValue();
      visibilityInfo.endParent = (ViewGroup)paramTransitionValues2.values.get("android:visibility:parent");
    } else {
      visibilityInfo.endVisibility = -1;
      visibilityInfo.endParent = null;
    } 
    if (paramTransitionValues1 != null && paramTransitionValues2 != null) {
      if (visibilityInfo.startVisibility == visibilityInfo.endVisibility && visibilityInfo.startParent == visibilityInfo.endParent)
        return visibilityInfo; 
      if (visibilityInfo.startVisibility != visibilityInfo.endVisibility) {
        if (visibilityInfo.startVisibility == 0) {
          visibilityInfo.fadeIn = false;
          visibilityInfo.visibilityChange = true;
        } else if (visibilityInfo.endVisibility == 0) {
          visibilityInfo.fadeIn = true;
          visibilityInfo.visibilityChange = true;
        } 
      } else if (visibilityInfo.startParent != visibilityInfo.endParent) {
        if (visibilityInfo.endParent == null) {
          visibilityInfo.fadeIn = false;
          visibilityInfo.visibilityChange = true;
        } else if (visibilityInfo.startParent == null) {
          visibilityInfo.fadeIn = true;
          visibilityInfo.visibilityChange = true;
        } 
      } 
    } 
    if (paramTransitionValues1 == null) {
      visibilityInfo.fadeIn = true;
      visibilityInfo.visibilityChange = true;
      return visibilityInfo;
    } 
    if (paramTransitionValues2 == null) {
      visibilityInfo.fadeIn = false;
      visibilityInfo.visibilityChange = true;
    } 
    return visibilityInfo;
  }
  
  public void captureEndValues(TransitionValues paramTransitionValues) {
    captureValues(paramTransitionValues);
  }
  
  public void captureStartValues(TransitionValues paramTransitionValues) {
    captureValues(paramTransitionValues);
  }
  
  public Animator createAnimator(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, TransitionValues paramTransitionValues2) {
    int i = 0;
    int j = -1;
    VisibilityInfo visibilityInfo = getVisibilityChangeInfo(paramTransitionValues1, paramTransitionValues2);
    if (visibilityInfo.visibilityChange) {
      if (this.mTargets.size() > 0 || this.mTargetIds.size() > 0) {
        View view1;
        View view2;
        if (paramTransitionValues1 != null) {
          view1 = paramTransitionValues1.view;
        } else {
          view1 = null;
        } 
        if (paramTransitionValues2 != null) {
          view2 = paramTransitionValues2.view;
        } else {
          view2 = null;
        } 
        if (view1 != null) {
          i = view1.getId();
        } else {
          i = -1;
        } 
        if (view2 != null)
          j = view2.getId(); 
        if (isValidTarget(view1, i) || isValidTarget(view2, j)) {
          i = 1;
        } else {
          i = 0;
        } 
      } 
      if (i != 0 || visibilityInfo.startParent != null || visibilityInfo.endParent != null)
        return visibilityInfo.fadeIn ? onAppear(paramViewGroup, paramTransitionValues1, visibilityInfo.startVisibility, paramTransitionValues2, visibilityInfo.endVisibility) : onDisappear(paramViewGroup, paramTransitionValues1, visibilityInfo.startVisibility, paramTransitionValues2, visibilityInfo.endVisibility); 
    } 
    return null;
  }
  
  public String[] getTransitionProperties() {
    return sTransitionProperties;
  }
  
  public boolean isVisible(TransitionValues paramTransitionValues) {
    if (paramTransitionValues == null)
      return false; 
    int i = ((Integer)paramTransitionValues.values.get("android:visibility:visibility")).intValue();
    View view = (View)paramTransitionValues.values.get("android:visibility:parent");
    return (i == 0 && view != null);
  }
  
  public Animator onAppear(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, int paramInt1, TransitionValues paramTransitionValues2, int paramInt2) {
    return null;
  }
  
  public Animator onDisappear(ViewGroup paramViewGroup, TransitionValues paramTransitionValues1, int paramInt1, TransitionValues paramTransitionValues2, int paramInt2) {
    return null;
  }
  
  private static class VisibilityInfo {
    ViewGroup endParent;
    
    int endVisibility;
    
    boolean fadeIn;
    
    ViewGroup startParent;
    
    int startVisibility;
    
    boolean visibilityChange;
  }
}
