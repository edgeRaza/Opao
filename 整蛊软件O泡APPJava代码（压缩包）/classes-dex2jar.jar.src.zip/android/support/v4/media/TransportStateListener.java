package android.support.v4.media;

@Deprecated
public class TransportStateListener {
  @Deprecated
  public void onPlayingChanged(TransportController paramTransportController) {}
  
  @Deprecated
  public void onTransportControlsChanged(TransportController paramTransportController) {}
}
