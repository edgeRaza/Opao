package android.support.v4.text;

public interface TextDirectionHeuristicCompat {
  boolean isRtl(CharSequence paramCharSequence, int paramInt1, int paramInt2);
  
  boolean isRtl(char[] paramArrayOfchar, int paramInt1, int paramInt2);
}
